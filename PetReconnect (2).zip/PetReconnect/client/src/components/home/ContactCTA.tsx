import React from 'react';
import { Button } from '@/components/ui/button';
import { PawPrint, Mail, Phone, MessageSquare } from 'lucide-react';

const ContactCTA: React.FC = () => {
  const contactMethods = [
    {
      icon: <Mail className="h-6 w-6" />,
      title: "Email Us",
      info: "help@petconnectatx.com"
    },
    {
      icon: <Phone className="h-6 w-6" />,
      title: "Call Hotline",
      info: "(800) 555-PETS"
    },
    {
      icon: <MessageSquare className="h-6 w-6" />,
      title: "Live Chat",
      info: "Available 9 AM - 8 PM"
    }
  ];

  return (
    <section id="contact" className="py-16 bg-primary/10">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="font-display font-bold text-3xl text-neutral-800 mb-4">Need Additional Help?</h2>
          <p className="text-lg text-neutral-600 mb-8">
            Our Austin-based team is ready to assist with special circumstances or difficult cases within our 50-mile service area. Reach out and we'll do everything we can to help.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center mb-8">
            {contactMethods.map((method, index) => (
              <div key={index}>
                <div className="w-12 h-12 mx-auto bg-primary/20 text-primary rounded-full flex items-center justify-center mb-3">
                  {method.icon}
                </div>
                <h3 className="font-display font-semibold mb-2">{method.title}</h3>
                <p className="text-neutral-600">{method.info}</p>
              </div>
            ))}
          </div>
          
          <Button
            className="inline-flex items-center bg-primary hover:bg-blue-600 text-white font-semibold px-6 py-3 h-auto rounded-full shadow-sm"
          >
            <PawPrint className="mr-2 h-5 w-5" />
            Contact Our Team
          </Button>
        </div>
      </div>
    </section>
  );
};

export default ContactCTA;
