import React, { useState } from 'react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const FAQ: React.FC = () => {
  const faqItems = [
    {
      question: "How does the AI matching system work?",
      answer: "Our AI system scans social media platforms like Nextdoor and Facebook for posts about lost and found pets within a 50-mile radius of Austin, TX. It analyzes images, descriptions, locations, and timestamps to find potential matches. The system uses computer vision to compare pet photos and natural language processing to extract relevant details from posts."
    },
    {
      question: "Is there a fee to use PetConnectATX?",
      answer: "Basic pet listings and matching services are completely free. We offer premium features like priority matching, extended search radius, and direct alerts to animal shelters for a small subscription fee. Our goal is to reunite as many pets as possible, regardless of ability to pay."
    },
    {
      question: "What should I do immediately after losing my pet?",
      answer: "First, search your immediate area thoroughly. Then report your lost pet on PetReunite with clear photos and detailed descriptions. We also recommend contacting local animal shelters, posting flyers in your neighborhood, and sharing on your social media accounts. The more visibility, the better chance of a reunion."
    },
    {
      question: "How can I help a pet I've found?",
      answer: "If you've found a pet, first check for ID tags or a microchip (any vet or shelter can scan for a chip). Report the found pet on PetReunite with photos and location details. If possible, temporarily shelter the pet while searching for the owner, or contact a local rescue organization that can provide temporary care."
    }
  ];

  return (
    <section id="faq" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="font-display font-bold text-3xl text-neutral-800 mb-4">Frequently Asked Questions</h2>
          <p className="text-lg text-neutral-600 max-w-2xl mx-auto">
            Get answers to common questions about our pet reunification service.
          </p>
        </div>
        
        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="space-y-6">
            {faqItems.map((item, index) => (
              <AccordionItem 
                key={index} 
                value={`item-${index}`}
                className="border border-neutral-200 rounded-lg overflow-hidden"
              >
                <AccordionTrigger className="px-6 py-4 text-left hover:no-underline hover:bg-neutral-50">
                  <span className="font-display font-semibold text-lg">{item.question}</span>
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-4 pt-2 text-neutral-600">
                  {item.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
};

export default FAQ;
