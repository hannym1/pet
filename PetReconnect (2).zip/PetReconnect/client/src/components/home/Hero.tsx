import React from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { MapPin } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="bg-gradient-to-br from-primary/10 to-secondary/10 py-12 md:py-20">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center gap-8 md:gap-12">
          <div className="md:w-1/2 text-center md:text-left">
            <div className="inline-flex items-center px-3 py-1 rounded-full bg-accent/20 text-accent mb-4">
              <MapPin className="w-4 h-4 mr-2" />
              <span className="font-medium text-sm">Austin, TX &amp; 50-mile radius</span>
            </div>
            <h1 className="font-display font-bold text-3xl md:text-4xl lg:text-5xl text-neutral-800 mb-4">
              Reunite With Your <span className="text-primary">Lost Pet</span>
            </h1>
            <p className="text-lg md:text-xl text-neutral-600 mb-8 max-w-xl">
              Our AI-powered platform scans social media to help find your missing pets in Austin and surrounding areas. We've already helped reunite over 5,000 pets with their families.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
              <Link href="/lost-pet">
                <Button 
                  className="bg-primary hover:bg-blue-600 text-white text-lg font-semibold px-6 py-3 h-auto rounded-full shadow-sm"
                >
                  I Lost My Pet
                </Button>
              </Link>
              <Link href="/found-pet">
                <Button 
                  className="bg-secondary hover:bg-green-600 text-white text-lg font-semibold px-6 py-3 h-auto rounded-full shadow-sm"
                >
                  I Found a Pet
                </Button>
              </Link>
            </div>
          </div>
          
          <div className="md:w-1/2">
            <img 
              src="https://images.unsplash.com/photo-1601758124510-52d02ddb7cbd?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
              alt="Family reunited with their lost pet"
              className="rounded-xl shadow-lg w-full h-auto"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
