import React from 'react';
import { Upload, Search, Heart } from 'lucide-react';

const HowItWorks: React.FC = () => {
  const steps = [
    {
      icon: <Upload className="h-8 w-8" />,
      title: "Report Your Pet",
      description: "Submit details about your lost pet or a pet you've found, including photos and location information."
    },
    {
      icon: <Search className="h-8 w-8" />,
      title: "AI-Powered Search",
      description: "Our system scans social media platforms like Nextdoor and Facebook to find potential matches."
    },
    {
      icon: <Heart className="h-8 w-8" />,
      title: "Get Reunited",
      description: "Receive notifications of potential matches and connect directly with the other party to reunite."
    }
  ];

  return (
    <section id="how-it-works" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="font-display font-bold text-3xl text-neutral-800 mb-4">How PetConnectATX Works</h2>
          <p className="text-lg text-neutral-600 max-w-2xl mx-auto">
            Our AI-powered platform searches across social media to find matches for lost and found pets within a 50-mile radius of Austin, TX.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {steps.map((step, index) => (
            <div 
              key={index} 
              className="bg-neutral-50 rounded-xl p-6 text-center flex flex-col items-center"
            >
              <div className="bg-primary/10 text-primary text-3xl w-16 h-16 rounded-full flex items-center justify-center mb-4">
                {step.icon}
              </div>
              <h3 className="font-display font-semibold text-xl mb-3">{step.title}</h3>
              <p className="text-neutral-600">
                {step.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
