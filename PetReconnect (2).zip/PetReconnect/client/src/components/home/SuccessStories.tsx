import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import { CheckCircle } from 'lucide-react';

interface SuccessStory {
  lostPet: {
    id: number;
    name: string;
    imageUrl: string;
    contactName: string;
    lastSeenLocation: string;
  };
  foundPet: {
    id: number;
    contactName: string;
  };
  reuniteDate: string;
}

const SuccessStories: React.FC = () => {
  const { data: successStories, isLoading, error } = useQuery({
    queryKey: ['/api/success-stories'],
    staleTime: 1000 * 60 * 5, // 5 minutes
  });

  if (error) {
    console.error('Error loading success stories:', error);
  }

  const storyExamples: SuccessStory[] = [
    {
      lostPet: {
        id: 1,
        name: "Bailey",
        imageUrl: "https://images.unsplash.com/photo-1516734212186-a967f81ad0d7?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600",
        contactName: "Sarah M.",
        lastSeenLocation: "Portland"
      },
      foundPet: {
        id: 2,
        contactName: "Mark J."
      },
      reuniteDate: "2023-10-08T00:00:00.000Z"
    },
    {
      lostPet: {
        id: 3,
        name: "Coco",
        imageUrl: "https://images.unsplash.com/photo-1577175889968-f551f5944abd?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600",
        contactName: "James T.",
        lastSeenLocation: "Chicago"
      },
      foundPet: {
        id: 4,
        contactName: "Lisa C."
      },
      reuniteDate: "2023-10-13T00:00:00.000Z"
    }
  ];

  // Use stories from API if available, otherwise use examples
  const stories = successStories || storyExamples;

  const getDaysToReunite = (story: SuccessStory) => {
    const lostDate = new Date(story.lostPet.reuniteDate || story.reuniteDate);
    const foundDate = new Date(story.foundPet.reuniteDate || story.reuniteDate);
    const diffTime = Math.abs(foundDate.getTime() - lostDate.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays || 7; // Default to 7 if calculation fails
  };

  return (
    <section id="success-stories" className="py-16 bg-neutral-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="font-display font-bold text-3xl text-neutral-800 mb-4">Reunification Success Stories</h2>
          <p className="text-lg text-neutral-600 max-w-2xl mx-auto">
            These heartwarming stories show how PetConnectATX has helped bring beloved pets back home in the Austin area.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {isLoading ? (
            // Loading skeleton
            Array(2).fill(0).map((_, i) => (
              <div key={i} className="bg-white rounded-xl overflow-hidden shadow-sm">
                <div className="flex flex-col md:flex-row">
                  <Skeleton className="w-full md:w-1/2 h-64" />
                  <div className="p-6 md:w-1/2">
                    <div className="flex items-center mb-4">
                      <Skeleton className="h-6 w-32" />
                    </div>
                    <Skeleton className="h-6 w-3/4 mb-3" />
                    <Skeleton className="h-20 w-full mb-4" />
                    <div className="flex items-center">
                      <Skeleton className="w-10 h-10 rounded-full" />
                      <Skeleton className="h-5 w-40 ml-3" />
                    </div>
                  </div>
                </div>
              </div>
            ))
          ) : (
            stories.map((story, index) => (
              <div key={index} className="bg-white rounded-xl overflow-hidden shadow-sm">
                <div className="flex flex-col md:flex-row">
                  <img 
                    src={story.lostPet.imageUrl} 
                    alt={`Reunion with ${story.lostPet.name}`}
                    className="w-full md:w-1/2 h-64 md:h-auto object-cover"
                  />
                  
                  <div className="p-6 md:w-1/2">
                    <div className="flex items-center mb-4">
                      <div className="bg-secondary/10 text-secondary text-lg p-1 rounded-full">
                        <CheckCircle className="h-5 w-5" />
                      </div>
                      <span className="ml-2 text-secondary font-semibold">
                        Reunited after {getDaysToReunite(story)} days
                      </span>
                    </div>
                    
                    <h3 className="font-display font-semibold text-xl mb-3">
                      {story.lostPet.name} Found {story.lostPet.name === 'Bailey' ? 'Her' : 'His'} Way Home
                    </h3>
                    
                    <p className="text-neutral-600 mb-4">
                      {story.lostPet.name === 'Bailey' 
                        ? "I was devastated when Bailey ran off during a thunderstorm. After a week of searching, PetReunite matched our post with someone who found her 3 miles away. We're so grateful to have our family complete again!"
                        : `Our dog ${story.lostPet.name} escaped through a hole in the fence. The AI system found a match on Nextdoor from a neighbor just 5 blocks away! The kids were overjoyed to have their best friend back.`}
                    </p>
                    
                    <div className="flex items-center">
                      <Avatar>
                        <AvatarImage src={`https://randomuser.me/api/portraits/${story.lostPet.name === 'Bailey' ? 'women/54' : 'men/32'}.jpg`} alt={story.lostPet.contactName} />
                        <AvatarFallback>{story.lostPet.contactName.split(' ')[0][0]}</AvatarFallback>
                      </Avatar>
                      <span className="ml-3 font-medium text-neutral-800">
                        {story.lostPet.contactName} from {story.lostPet.lastSeenLocation}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </section>
  );
};

export default SuccessStories;
