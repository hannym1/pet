import React from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { PetStatus } from '@shared/schema';
import { MapPin, PawPrint } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

interface PetCardProps {
  pet: {
    id: number;
    name: string;
    status: string;
    petType: string;
    breed?: string;
    gender?: string;
    lastSeenDate?: Date | string;
    lastSeenLocation?: string;
    description?: string;
    imageUrl?: string;
    createdAt?: Date | string;
  };
}

const PetCard: React.FC<PetCardProps> = ({ pet }) => {
  const createdAt = pet.createdAt ? new Date(pet.createdAt) : new Date();
  const timeAgo = formatDistanceToNow(createdAt, { addSuffix: true });

  return (
    <div className="bg-white border border-neutral-200 rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow">
      <div className="relative">
        <img 
          src={pet.imageUrl || `https://placehold.co/800x600/e2e8f0/64748b?text=${pet.name.charAt(0)}`} 
          alt={`${pet.status === 'lost' ? 'Lost' : 'Found'} ${pet.petType} - ${pet.name}`}
          className="w-full h-64 object-cover"
        />
        <span 
          className={`absolute top-4 left-4 text-white text-sm font-semibold px-3 py-1 rounded-full ${
            pet.status === PetStatus.LOST 
              ? 'bg-accent' 
              : pet.status === PetStatus.FOUND 
                ? 'bg-secondary' 
                : 'bg-primary'
          }`}
        >
          {pet.status.charAt(0).toUpperCase() + pet.status.slice(1)}
        </span>
      </div>
      
      <div className="p-5">
        <div className="flex justify-between items-start mb-3">
          <h3 className="font-display font-semibold text-xl">{pet.name}</h3>
          <span className="text-sm text-neutral-500">{timeAgo}</span>
        </div>
        
        <div className="mb-3">
          {pet.lastSeenLocation && (
            <p className="text-neutral-700 mb-1">
              <MapPin className="inline-block w-4 h-4 text-accent mr-2" /> 
              {pet.lastSeenLocation}
            </p>
          )}
          {(pet.petType || pet.breed || pet.gender) && (
            <p className="text-neutral-700">
              <PawPrint className="inline-block w-4 h-4 text-primary mr-2" /> 
              {[
                pet.breed, 
                pet.gender
              ].filter(Boolean).join(', ') || pet.petType.charAt(0).toUpperCase() + pet.petType.slice(1)}
            </p>
          )}
        </div>
        
        {pet.description && (
          <p className="text-neutral-600 mb-4 line-clamp-2">
            {pet.description}
          </p>
        )}
        
        <Link href={`/pets/${pet.id}`}>
          <Button
            className="w-full bg-primary hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded-lg transition-colors"
          >
            View Details
          </Button>
        </Link>
      </div>
    </div>
  );
};

export default PetCard;
