import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { insertPetSchema, PetStatus, PetType } from '@shared/schema';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useLocation } from 'wouter';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Dropzone } from '@/components/ui/dropzone';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { format } from 'date-fns';

interface PetFormProps {
  type: 'lost' | 'found';
}

// Extend the insert schema with additional validation
const petFormSchema = insertPetSchema.extend({
  lastSeenDate: z.string().optional(),
  contactInfo: z.string().min(5, {
    message: "Contact information is required",
  }),
  petType: z.string().min(1, {
    message: "Pet type is required",
  }),
});

type PetFormData = z.infer<typeof petFormSchema>;

const PetForm: React.FC<PetFormProps> = ({ type }) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, navigate] = useLocation();
  
  // For file upload
  const [file, setFile] = useState<File | null>(null);
  
  // Form setup
  const form = useForm<PetFormData>({
    resolver: zodResolver(petFormSchema),
    defaultValues: {
      status: type === 'lost' ? PetStatus.LOST : PetStatus.FOUND,
      name: type === 'found' ? 'Unknown Pet' : '',
      petType: '',
      lastSeenLocation: '',
      description: '',
      contactInfo: '',
      contactName: '',
      isTemporarilyCaredFor: type === 'found' ? true : false,
    },
  });
  
  // API mutation to create pet
  const createPetMutation = useMutation({
    mutationFn: async (data: PetFormData) => {
      // First upload the image if we have one
      let imageUrl = '';
      if (file) {
        // In a real app, we would upload the file to a storage service
        // For the MVP, we'll use a mock/dummy URL
        imageUrl = URL.createObjectURL(file);
      }
      
      // Format the data for the API
      const petData = {
        ...data,
        lastSeenDate: data.lastSeenDate ? new Date(data.lastSeenDate) : new Date(),
        imageUrl: imageUrl || undefined,
      };
      
      const response = await apiRequest('POST', '/api/pets', petData);
      return await response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/pets'] });
      toast({
        title: "Pet report submitted!",
        description: "We'll notify you of any potential matches.",
      });
      navigate('/pets/' + data.id);
    },
    onError: (error) => {
      toast({
        title: "Error submitting pet report",
        description: error.message || "Please try again later.",
        variant: "destructive",
      });
    },
  });
  
  const onSubmit = (data: PetFormData) => {
    createPetMutation.mutate(data);
  };
  
  const handleFilesAdded = (files: File[]) => {
    if (files && files.length > 0) {
      setFile(files[0]);
    }
  };
  
  const clearFile = () => {
    setFile(null);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="petType"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="text-neutral-700 font-medium">Pet Type</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger className="w-full border-neutral-300 focus:ring-2 focus:ring-primary focus:border-primary">
                    <SelectValue placeholder="Select pet type" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value={PetType.DOG}>Dog</SelectItem>
                  <SelectItem value={PetType.CAT}>Cat</SelectItem>
                  <SelectItem value={PetType.BIRD}>Bird</SelectItem>
                  <SelectItem value={PetType.OTHER}>Other</SelectItem>
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="text-neutral-700 font-medium">
                {type === 'lost' ? "Pet's Name" : "Pet's Name (if known)"}
              </FormLabel>
              <FormControl>
                <Input 
                  {...field} 
                  placeholder={type === 'lost' ? "Enter your pet's name" : "Enter pet's name if known"}
                  className="w-full border-neutral-300 focus:ring-2 focus:ring-primary focus:border-primary"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FormField
            control={form.control}
            name="lastSeenLocation"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-neutral-700 font-medium">
                  {type === 'lost' ? "Last Seen Location" : "Found Location"}
                </FormLabel>
                <FormControl>
                  <Input 
                    {...field} 
                    placeholder="Enter address, neighborhood, or landmark"
                    className="w-full border-neutral-300 focus:ring-2 focus:ring-primary focus:border-primary"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="lastSeenDate"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-neutral-700 font-medium">
                  {type === 'lost' ? "Date Lost" : "Date Found"}
                </FormLabel>
                <FormControl>
                  <Input 
                    type="date"
                    {...field} 
                    max={format(new Date(), 'yyyy-MM-dd')}
                    className="w-full border-neutral-300 focus:ring-2 focus:ring-primary focus:border-primary"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        
        <FormItem>
          <FormLabel className="text-neutral-700 font-medium">Pet Photo</FormLabel>
          <Dropzone 
            onFilesAdded={handleFilesAdded}
            value={file ? [file] : []}
            onClear={clearFile}
            className="w-full border-neutral-300 focus:ring-2 focus:ring-primary focus:border-primary"
          />
          <FormDescription>
            Clear, recent photos work best for matching
          </FormDescription>
        </FormItem>
        
        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="text-neutral-700 font-medium">Description</FormLabel>
              <FormControl>
                <Textarea 
                  {...field} 
                  placeholder={`Describe the pet's appearance, breed, color, distinctive features, etc.`}
                  className="w-full border-neutral-300 focus:ring-2 focus:ring-primary focus:border-primary"
                  rows={4}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FormField
            control={form.control}
            name="contactName"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-neutral-700 font-medium">Your Name</FormLabel>
                <FormControl>
                  <Input 
                    {...field} 
                    placeholder="Enter your name"
                    className="w-full border-neutral-300 focus:ring-2 focus:ring-primary focus:border-primary"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="contactInfo"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-neutral-700 font-medium">Your Contact Information</FormLabel>
                <FormControl>
                  <Input 
                    {...field} 
                    placeholder="Phone number or email"
                    className="w-full border-neutral-300 focus:ring-2 focus:ring-primary focus:border-primary"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        
        {type === 'found' && (
          <FormField
            control={form.control}
            name="isTemporarilyCaredFor"
            render={({ field }) => (
              <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                <FormControl>
                  <Checkbox
                    checked={field.value}
                    onCheckedChange={field.onChange}
                    className="data-[state=checked]:bg-primary data-[state=checked]:border-primary"
                  />
                </FormControl>
                <div className="space-y-1 leading-none">
                  <FormLabel className="text-neutral-700">
                    I am temporarily caring for this pet
                  </FormLabel>
                </div>
              </FormItem>
            )}
          />
        )}
        
        <Button 
          type="submit" 
          className={`w-full font-semibold py-3 px-6 rounded-lg transition-colors shadow-sm ${
            type === 'lost' 
              ? "bg-primary hover:bg-blue-600 text-white" 
              : "bg-secondary hover:bg-green-600 text-white"
          }`}
          disabled={createPetMutation.isPending}
        >
          {createPetMutation.isPending ? "Submitting..." : `Submit ${type === 'lost' ? 'Lost' : 'Found'} Pet Report`}
        </Button>
      </form>
    </Form>
  );
};

export default PetForm;
