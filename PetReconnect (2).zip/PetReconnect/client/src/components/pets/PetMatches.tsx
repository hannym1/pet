import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { Pet } from '@shared/schema';
import PetCard from './PetCard';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { AlertCircle } from 'lucide-react';

interface PetMatchesProps {
  petId: number;
  petType?: string;
}

const PetMatches: React.FC<PetMatchesProps> = ({ petId, petType }) => {
  const { data: matches, isLoading, error } = useQuery({
    queryKey: [`/api/pets/${petId}/matches`],
    enabled: !!petId,
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {Array(3).fill(0).map((_, i) => (
          <div key={i} className="bg-white border border-neutral-200 rounded-xl overflow-hidden shadow-sm">
            <Skeleton className="w-full h-64" />
            <div className="p-5">
              <div className="flex justify-between items-start mb-3">
                <Skeleton className="h-6 w-32" />
                <Skeleton className="h-4 w-16" />
              </div>
              <div className="mb-3">
                <Skeleton className="h-4 w-full mb-1" />
                <Skeleton className="h-4 w-3/4" />
              </div>
              <Skeleton className="h-20 w-full mb-4" />
              <Skeleton className="h-10 w-full rounded-lg" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 p-4 rounded-lg flex items-start gap-3">
        <AlertCircle className="h-5 w-5 text-red-500 mt-0.5" />
        <div>
          <h3 className="font-semibold text-red-800">Error loading matches</h3>
          <p className="text-red-700 text-sm">{(error as Error).message || "Please try again later"}</p>
        </div>
      </div>
    );
  }

  if (!matches || matches.length === 0) {
    return (
      <div className="text-center py-8 px-4 bg-neutral-50 rounded-xl">
        <div className="mb-4 text-neutral-400">
          <AlertCircle className="h-12 w-12 mx-auto" />
        </div>
        <h3 className="text-xl font-display font-semibold mb-2">No matches found yet</h3>
        <p className="text-neutral-600 max-w-md mx-auto mb-6">
          We're continuously scanning social media and our database for potential matches. We'll notify you when we find something!
        </p>
        <div className="flex flex-wrap gap-3 justify-center">
          <Link href="/search">
            <Button variant="outline">Browse All Listings</Button>
          </Link>
          <a href="#share" onClick={(e) => e.preventDefault()}>
            <Button variant="secondary">Share on Social Media</Button>
          </a>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {matches.map((match: Pet) => (
          <PetCard key={match.id} pet={match} />
        ))}
      </div>
      
      {matches.length > 6 && (
        <div className="mt-8 text-center">
          <Button 
            variant="outline" 
            className="px-6 py-3 border border-primary text-primary font-semibold rounded-full hover:bg-primary hover:text-white transition-colors"
          >
            Load More Matches
          </Button>
        </div>
      )}
    </div>
  );
};

export default PetMatches;
