import React from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { PawPrint, Facebook, Twitter, Instagram, Linkedin, Send, MapPin } from 'lucide-react';

const Footer: React.FC = () => {
  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    // In a real app, we would submit the email to a newsletter service
  };
  
  return (
    <footer className="bg-neutral-800 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <span className="text-primary text-3xl">
                <PawPrint className="h-8 w-8" />
              </span>
              <div>
                <h3 className="font-display font-bold text-xl">PetConnectATX</h3>
                <div className="text-xs text-neutral-400 flex items-center">
                  <MapPin className="h-3 w-3 mr-1" />
                  <span>Austin, TX (50-mile radius)</span>
                </div>
              </div>
            </div>
            
            <p className="text-neutral-300 mb-4">
              Bringing lost pets back to their loving families throughout Austin and surrounding areas through technology and community.
            </p>
            
            <div className="flex gap-4">
              <a href="#" className="text-neutral-300 hover:text-primary transition-colors">
                <Facebook className="h-5 w-5" />
                <span className="sr-only">Facebook</span>
              </a>
              <a href="#" className="text-neutral-300 hover:text-primary transition-colors">
                <Twitter className="h-5 w-5" />
                <span className="sr-only">Twitter</span>
              </a>
              <a href="#" className="text-neutral-300 hover:text-primary transition-colors">
                <Instagram className="h-5 w-5" />
                <span className="sr-only">Instagram</span>
              </a>
              <a href="#" className="text-neutral-300 hover:text-primary transition-colors">
                <Linkedin className="h-5 w-5" />
                <span className="sr-only">LinkedIn</span>
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="font-display font-semibold text-lg mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li><Link href="/lost-pet" className="text-neutral-300 hover:text-primary transition-colors">Report Lost Pet</Link></li>
              <li><Link href="/found-pet" className="text-neutral-300 hover:text-primary transition-colors">Report Found Pet</Link></li>
              <li><Link href="/search" className="text-neutral-300 hover:text-primary transition-colors">Search Listings</Link></li>
              <li><Link href="/#success-stories" className="text-neutral-300 hover:text-primary transition-colors">Success Stories</Link></li>
              <li><Link href="/#how-it-works" className="text-neutral-300 hover:text-primary transition-colors">About Us</Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-display font-semibold text-lg mb-4">Resources</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-neutral-300 hover:text-primary transition-colors">Pet Safety Tips</a></li>
              <li><a href="#" className="text-neutral-300 hover:text-primary transition-colors">Finding a Lost Pet</a></li>
              <li><a href="#" className="text-neutral-300 hover:text-primary transition-colors">Caring for Found Pets</a></li>
              <li><a href="#" className="text-neutral-300 hover:text-primary transition-colors">Microchipping</a></li>
              <li><a href="#" className="text-neutral-300 hover:text-primary transition-colors">Local Shelters</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-display font-semibold text-lg mb-4">Newsletter</h4>
            <p className="text-neutral-300 mb-4">
              Subscribe for updates on new features and success stories.
            </p>
            
            <form className="flex" onSubmit={handleSubmit}>
              <Input 
                type="email" 
                placeholder="Your email" 
                className="rounded-l-lg bg-white text-neutral-800 focus:ring-primary"
                required
              />
              <Button
                type="submit"
                className="bg-primary hover:bg-blue-600 text-white rounded-r-lg"
                size="icon"
              >
                <Send className="h-4 w-4" />
                <span className="sr-only">Subscribe</span>
              </Button>
            </form>
          </div>
        </div>
        
        <div className="pt-8 border-t border-neutral-700 text-center text-neutral-400 text-sm">
          <p>© {new Date().getFullYear()} PetReunite. All rights reserved. | <a href="#" className="hover:text-primary transition-colors">Privacy Policy</a> | <a href="#" className="hover:text-primary transition-colors">Terms of Service</a></p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
