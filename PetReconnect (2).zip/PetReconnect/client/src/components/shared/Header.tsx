import React, { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { Button } from "@/components/ui/button";
import { Menu, X, PawPrint, MapPin } from 'lucide-react';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [location] = useLocation();
  
  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);
  
  const navLinks = [
    { title: "How It Works", href: "/#how-it-works" },
    { title: "Success Stories", href: "/#success-stories" },
    { title: "FAQ", href: "/#faq" },
    { title: "Contact", href: "/#contact" }
  ];
  
  const isActive = (path: string) => {
    if (path.startsWith('/#')) {
      return location === '/';
    }
    return location === path;
  };

  return (
    <header className="bg-white shadow-sm sticky top-0 z-10">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          <span className="text-primary text-4xl">
            <PawPrint className="h-8 w-8" />
          </span>
          <div>
            <h1 className="font-display font-bold text-xl md:text-2xl text-neutral-800">PetConnectATX</h1>
            <div className="flex items-center text-xs text-neutral-500">
              <MapPin className="h-3 w-3 mr-1" />
              <span>Austin, TX (50-mile radius)</span>
            </div>
          </div>
        </Link>
        
        <nav className="hidden md:flex items-center gap-6">
          {navLinks.map((link) => (
            <Link 
              key={link.href}
              href={link.href}
              className={`font-medium transition-colors ${
                isActive(link.href) ? 'text-primary' : 'hover:text-primary'
              }`}
            >
              {link.title}
            </Link>
          ))}
        </nav>
        
        <div className="flex items-center gap-3">
          <Link href="/lost-pet">
            <Button 
              variant="default" 
              className="bg-accent hover:bg-amber-500 text-white font-semibold rounded-full shadow-sm"
              size="sm"
            >
              Report Pet
            </Button>
          </Link>
          
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={toggleMenu}
            aria-label="Toggle menu"
          >
            {isMenuOpen ? (
              <X className="h-6 w-6 text-neutral-700" />
            ) : (
              <Menu className="h-6 w-6 text-neutral-700" />
            )}
          </Button>
        </div>
      </div>
      
      {isMenuOpen && (
        <div className="md:hidden px-4 py-3 bg-white border-t border-neutral-200">
          <nav className="flex flex-col gap-3">
            {navLinks.map((link) => (
              <Link 
                key={link.href}
                href={link.href}
                className={`py-2 font-medium transition-colors ${
                  isActive(link.href) ? 'text-primary' : 'hover:text-primary'
                }`}
                onClick={() => setIsMenuOpen(false)}
              >
                {link.title}
              </Link>
            ))}
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;
