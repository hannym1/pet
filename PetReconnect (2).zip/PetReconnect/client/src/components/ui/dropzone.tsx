import * as React from "react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Upload, XCircle } from "lucide-react";

interface DropzoneProps {
  className?: string;
  onFilesAdded: (files: File[]) => void;
  maxFiles?: number;
  maxSize?: number; // in bytes
  acceptedFileTypes?: string[];
  disabled?: boolean;
  value?: File[];
  onClear?: () => void;
}

export function Dropzone({
  className,
  onFilesAdded,
  maxFiles = 1,
  maxSize = 1024 * 1024 * 10, // 10MB
  acceptedFileTypes = ["image/jpeg", "image/png", "image/jpg", "image/gif", "image/webp"],
  disabled = false,
  value,
  onClear,
}: DropzoneProps) {
  const [isDragging, setIsDragging] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [preview, setPreview] = React.useState<string | null>(null);
  
  const fileInputRef = React.useRef<HTMLInputElement>(null);
  
  React.useEffect(() => {
    if (value && value.length > 0 && value[0]) {
      const file = value[0];
      const reader = new FileReader();
      reader.onload = () => {
        setPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    } else {
      setPreview(null);
    }
  }, [value]);
  
  const handleDragEnter = React.useCallback(
    (e: React.DragEvent<HTMLDivElement>) => {
      e.preventDefault();
      e.stopPropagation();
      if (disabled) return;
      setIsDragging(true);
    },
    [disabled]
  );
  
  const handleDragLeave = React.useCallback(
    (e: React.DragEvent<HTMLDivElement>) => {
      e.preventDefault();
      e.stopPropagation();
      setIsDragging(false);
    },
    []
  );
  
  const handleDragOver = React.useCallback(
    (e: React.DragEvent<HTMLDivElement>) => {
      e.preventDefault();
      e.stopPropagation();
      if (disabled) return;
      e.dataTransfer.dropEffect = "copy";
      setIsDragging(true);
    },
    [disabled]
  );
  
  const validateFiles = React.useCallback(
    (files: File[]): File[] => {
      if (files.length > maxFiles) {
        setError(`Maximum ${maxFiles} file${maxFiles === 1 ? "" : "s"} allowed`);
        return [];
      }
      
      const validFiles = Array.from(files).filter((file) => {
        if (!acceptedFileTypes.includes(file.type)) {
          setError(`File type not allowed: ${file.type}`);
          return false;
        }
        
        if (file.size > maxSize) {
          setError(
            `File too large. Maximum size is ${Math.round(maxSize / 1024 / 1024)}MB`
          );
          return false;
        }
        
        return true;
      });
      
      if (validFiles.length > 0) {
        setError(null);
      }
      
      return validFiles;
    },
    [acceptedFileTypes, maxFiles, maxSize]
  );
  
  const handleDrop = React.useCallback(
    (e: React.DragEvent<HTMLDivElement>) => {
      e.preventDefault();
      e.stopPropagation();
      if (disabled) return;
      
      setIsDragging(false);
      
      const droppedFiles = Array.from(e.dataTransfer.files);
      const validFiles = validateFiles(droppedFiles);
      
      if (validFiles.length > 0) {
        onFilesAdded(validFiles);
      }
    },
    [disabled, onFilesAdded, validateFiles]
  );
  
  const handleChange = React.useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      if (disabled) return;
      
      const fileList = e.target.files;
      if (!fileList) return;
      
      const files = Array.from(fileList);
      const validFiles = validateFiles(files);
      
      if (validFiles.length > 0) {
        onFilesAdded(validFiles);
      }
      
      // Reset file input
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    },
    [disabled, onFilesAdded, validateFiles]
  );
  
  const handleButtonClick = React.useCallback(() => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  }, []);
  
  const handleClear = React.useCallback(() => {
    setPreview(null);
    if (onClear) {
      onClear();
    }
  }, [onClear]);
  
  return (
    <div className={cn("relative", className)}>
      {/* File Input (Hidden) */}
      <input
        type="file"
        ref={fileInputRef}
        className="sr-only"
        onChange={handleChange}
        accept={acceptedFileTypes.join(",")}
        multiple={maxFiles > 1}
        disabled={disabled}
      />
      
      {/* Dropzone */}
      <div
        className={cn(
          "border-2 border-dashed rounded-lg p-6 text-center transition-colors cursor-pointer",
          isDragging ? "border-primary bg-primary/5" : "border-neutral-300 hover:border-primary",
          disabled && "opacity-60 cursor-not-allowed",
          className
        )}
        onDragEnter={handleDragEnter}
        onDragLeave={handleDragLeave}
        onDragOver={handleDragOver}
        onDrop={handleDrop}
        onClick={handleButtonClick}
      >
        {preview ? (
          <div className="relative">
            <img
              src={preview}
              alt="Upload preview"
              className="mx-auto max-h-48 rounded-md object-contain"
            />
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                handleClear();
              }}
              className="absolute -top-2 -right-2 bg-white rounded-full text-neutral-500 hover:text-destructive"
            >
              <XCircle className="h-6 w-6" />
              <span className="sr-only">Remove image</span>
            </button>
          </div>
        ) : (
          <>
            <Upload className="h-12 w-12 text-neutral-400 mx-auto mb-4" />
            <p className="text-neutral-600 mb-2 text-lg font-medium">
              Drag & drop your pet's photo here
            </p>
            <p className="text-sm text-neutral-500 mb-4">
              or click to browse from your device
            </p>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={(e) => {
                e.stopPropagation();
                handleButtonClick();
              }}
              disabled={disabled}
            >
              Select file
            </Button>
          </>
        )}
      </div>
      
      {/* Error Message */}
      {error && <p className="text-destructive text-sm mt-2">{error}</p>}
      
      {/* Helper Text */}
      <p className="text-xs text-neutral-500 mt-2">
        Accepted file types: JPG, PNG, GIF, WEBP. Max size: {Math.round(maxSize / 1024 / 1024)}MB.
      </p>
    </div>
  );
}
