import React from 'react';
import { Helmet } from 'react-helmet';
import PetForm from '@/components/pets/PetForm';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Heart } from 'lucide-react';

const FoundPet: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Report a Found Pet - PetReunite</title>
        <meta 
          name="description" 
          content="Report a pet you've found to PetReunite. Our AI-powered platform will help find the pet's owner by analyzing social media posts and comparing pet photos."
        />
      </Helmet>

      <div className="bg-gradient-to-br from-secondary/5 to-primary/5 py-8 md:py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-8">
              <span className="inline-block bg-secondary/10 text-secondary p-3 rounded-full mb-4">
                <Heart className="h-8 w-8" />
              </span>
              <h1 className="font-display font-bold text-3xl text-neutral-800 mb-2">Report a Found Pet</h1>
              <p className="text-neutral-600 text-lg">
                Thank you for caring! Your information helps reunite pets with their families.
              </p>
            </div>
            
            <Card className="border-none shadow-md">
              <CardHeader>
                <CardTitle className="text-2xl font-display">Found Pet Information</CardTitle>
                <CardDescription>
                  Please provide as much detail as possible about the pet you've found.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <PetForm type="found" />
              </CardContent>
            </Card>
            
            <div className="mt-8 bg-green-50 border border-green-100 rounded-lg p-4">
              <h3 className="font-semibold text-green-800 mb-2">What to Do With a Found Pet</h3>
              <ul className="text-green-700 space-y-2 text-sm">
                <li>Check for ID tags or a microchip (any veterinarian or shelter can scan for a chip).</li>
                <li>If it's safe, provide temporary shelter, food, and water for the animal.</li>
                <li>Contact local animal shelters and veterinary clinics to report the found pet.</li>
                <li>If you can't keep the pet temporarily, contact your local animal control or a rescue organization.</li>
                <li>Take clear photos to help with identification and matching.</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default FoundPet;
