import React from 'react';
import { Helmet } from 'react-helmet';
import Hero from '@/components/home/Hero';
import HowItWorks from '@/components/home/HowItWorks';
import SuccessStories from '@/components/home/SuccessStories';
import FAQ from '@/components/home/FAQ';
import ContactCTA from '@/components/home/ContactCTA';
import { useQuery } from '@tanstack/react-query';
import { Pet, PetStatus, PetType } from '@shared/schema';
import PetCard from '@/components/pets/PetCard';
import { Button } from '@/components/ui/button';
import { Link } from 'wouter';

const Home: React.FC = () => {
  const { data: pets, isLoading } = useQuery({
    queryKey: ['/api/pets'],
    staleTime: 1000 * 60 * 5, // 5 minutes
  });

  // Filter pets for display in the 'Potential Matches' section
  const filteredPets = React.useMemo(() => {
    if (!pets) return [];
    
    // Only show lost and found pets (not reunited)
    return pets
      .filter((pet: Pet) => pet.status !== PetStatus.REUNITED)
      .sort((a: Pet, b: Pet) => {
        // Sort by most recent
        const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
        const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
        return dateB - dateA;
      })
      .slice(0, 6); // Only show the first 6
  }, [pets]);

  const petTypes = [
    { label: 'All', value: 'all' },
    { label: 'Dogs', value: PetType.DOG },
    { label: 'Cats', value: PetType.CAT },
    { label: 'Other', value: 'other' },
  ];

  const [activeFilter, setActiveFilter] = React.useState('all');

  const filteredByTypePets = React.useMemo(() => {
    if (activeFilter === 'all') return filteredPets;
    if (activeFilter === 'other') {
      return filteredPets.filter(
        (pet: Pet) => pet.petType !== PetType.DOG && pet.petType !== PetType.CAT
      );
    }
    return filteredPets.filter((pet: Pet) => pet.petType === activeFilter);
  }, [filteredPets, activeFilter]);

  return (
    <>
      <Helmet>
        <title>PetReunite - Bringing Lost Pets Home</title>
        <meta name="description" content="Our AI-powered platform helps reunite lost pets with their owners by analyzing social media posts and comparing pet photos." />
      </Helmet>

      <Hero />
      <HowItWorks />
      
      {/* Potential Matches Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="font-display font-bold text-3xl text-neutral-800 mb-4">Potential Matches</h2>
            <p className="text-lg text-neutral-600 max-w-2xl mx-auto">
              Our AI has found these potential matches based on recent reports and social media posts.
            </p>
          </div>
          
          <div className="mb-8 flex justify-center">
            <div className="inline-flex p-1 bg-neutral-100 rounded-full">
              {petTypes.map((type) => (
                <button
                  key={type.value}
                  className={`px-6 py-2 rounded-full font-medium transition-colors ${
                    activeFilter === type.value
                      ? 'bg-primary text-white'
                      : 'text-neutral-700 hover:bg-neutral-200'
                  }`}
                  onClick={() => setActiveFilter(type.value)}
                >
                  {type.label}
                </button>
              ))}
            </div>
          </div>
          
          {isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {Array(6).fill(0).map((_, i) => (
                <div key={i} className="bg-white border border-neutral-200 rounded-xl overflow-hidden shadow-sm animate-pulse">
                  <div className="bg-neutral-200 h-64 w-full"></div>
                  <div className="p-5">
                    <div className="h-6 bg-neutral-200 rounded w-2/3 mb-3"></div>
                    <div className="h-4 bg-neutral-200 rounded w-full mb-2"></div>
                    <div className="h-4 bg-neutral-200 rounded w-3/4 mb-4"></div>
                    <div className="h-10 bg-neutral-200 rounded w-full"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : filteredByTypePets.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredByTypePets.map((pet: Pet) => (
                <PetCard key={pet.id} pet={pet} />
              ))}
            </div>
          ) : (
            <div className="text-center py-10">
              <p className="text-neutral-600 mb-4">No pets found for this filter. Try another category or check back later.</p>
              <Link href="/search">
                <Button variant="outline">View All Listings</Button>
              </Link>
            </div>
          )}
          
          <div className="mt-8 text-center">
            <Link href="/search">
              <Button 
                variant="outline" 
                className="px-6 py-3 border border-primary text-primary font-semibold rounded-full hover:bg-primary hover:text-white transition-colors"
              >
                View All Listings
              </Button>
            </Link>
          </div>
        </div>
      </section>
      
      <SuccessStories />
      <FAQ />
      <ContactCTA />
    </>
  );
};

export default Home;
