import React from 'react';
import { Helmet } from 'react-helmet';
import PetForm from '@/components/pets/PetForm';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { PawPrint } from 'lucide-react';

const LostPet: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Report a Lost Pet - PetReunite</title>
        <meta 
          name="description" 
          content="Report your lost pet to PetReunite. Our AI-powered platform will help you find your pet by analyzing social media posts and comparing pet photos."
        />
      </Helmet>

      <div className="bg-gradient-to-br from-primary/5 to-secondary/5 py-8 md:py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-8">
              <span className="inline-block bg-primary/10 text-primary p-3 rounded-full mb-4">
                <PawPrint className="h-8 w-8" />
              </span>
              <h1 className="font-display font-bold text-3xl text-neutral-800 mb-2">Report a Lost Pet</h1>
              <p className="text-neutral-600 text-lg">
                Fill out this form with as much detail as possible to help us find your pet.
              </p>
            </div>
            
            <Card className="border-none shadow-md">
              <CardHeader>
                <CardTitle className="text-2xl font-display">Lost Pet Information</CardTitle>
                <CardDescription>
                  We'll use this information to match your pet with found reports and social media posts.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <PetForm type="lost" />
              </CardContent>
            </Card>
            
            <div className="mt-8 bg-blue-50 border border-blue-100 rounded-lg p-4">
              <h3 className="font-semibold text-blue-800 mb-2">Tips for Finding Your Lost Pet</h3>
              <ul className="text-blue-700 space-y-2 text-sm">
                <li>Search your immediate surroundings thoroughly, including under porches and in garages.</li>
                <li>Put out items with familiar scents (your pet's bed, toys, your unwashed clothing).</li>
                <li>Contact local animal shelters, veterinary offices, and animal control.</li>
                <li>Post flyers in your neighborhood with a clear photo and your contact information.</li>
                <li>Share on your social media accounts and local community groups.</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default LostPet;
