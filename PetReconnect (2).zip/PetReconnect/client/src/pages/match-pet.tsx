import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { PetType, PetStatus } from '@shared/schema';
import { Loader2, Upload } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import Layout from '@/components/shared/Layout';

export default function MatchPet() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [petType, setPetType] = useState<string>('');
  const [status, setStatus] = useState<string>('lost'); // Default to looking for lost pets
  const { toast } = useToast();

  // File selection handler
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    if (file) {
      setSelectedFile(file);
      const fileUrl = URL.createObjectURL(file);
      setPreviewUrl(fileUrl);
    }
  };

  // Image matching mutation
  const matchMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const response = await apiRequest("/api/image-match", {
        method: "POST",
        body: formData,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Image uploaded",
        description: "Image analyzed successfully for potential matches",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to analyze image: " + (error as Error).message,
        variant: "destructive",
      });
    },
  });

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedFile) {
      toast({
        title: "No image selected",
        description: "Please select an image to upload",
        variant: "destructive",
      });
      return;
    }

    const formData = new FormData();
    formData.append('petImage', selectedFile);
    
    // Add optional filters
    if (petType) formData.append('petType', petType);
    if (status) formData.append('status', status);

    matchMutation.mutate(formData);
  };

  // Get confidence badge color
  const getConfidenceBadgeColor = (confidence: string) => {
    switch(confidence) {
      case 'high': return 'bg-green-500';
      case 'medium': return 'bg-yellow-500';
      case 'low': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  // Get score progress color
  const getScoreColor = (score: number) => {
    if (score > 0.7) return 'bg-green-500';
    if (score > 0.4) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  return (
    <Layout>
      <div className="container mx-auto py-10">
        <h1 className="text-3xl font-bold mb-6">Find Your Pet with Photo Matching</h1>
        <p className="text-lg text-neutral-600 mb-8">
          Upload a photo of your pet and our AI will compare it with other pets in the Austin area to help you find potential matches.
        </p>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Upload Form */}
          <Card>
            <CardHeader>
              <CardTitle>Upload Pet Photo</CardTitle>
              <CardDescription>
                Please upload a clear photo of the pet you're looking for
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="status">I'm looking for my</Label>
                    <Select 
                      value={status} 
                      onValueChange={setStatus}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value={PetStatus.LOST}>Lost Pet</SelectItem>
                        <SelectItem value={PetStatus.FOUND}>Pet I Found</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="petType">Pet Type (Optional)</Label>
                    <Select 
                      value={petType} 
                      onValueChange={setPetType}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select pet type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">Any type</SelectItem>
                        <SelectItem value={PetType.DOG}>Dog</SelectItem>
                        <SelectItem value={PetType.CAT}>Cat</SelectItem>
                        <SelectItem value={PetType.BIRD}>Bird</SelectItem>
                        <SelectItem value={PetType.OTHER}>Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="image">Pet Photo</Label>
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-primary transition-colors cursor-pointer"
                      onClick={() => document.getElementById('image-upload')?.click()}
                    >
                      <Input 
                        id="image-upload" 
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={handleFileChange}
                      />
                      {previewUrl ? (
                        <div className="space-y-2">
                          <img 
                            src={previewUrl} 
                            alt="Preview" 
                            className="mx-auto max-h-64 rounded-lg shadow-sm" 
                          />
                          <p className="text-sm text-gray-500">Click to change image</p>
                        </div>
                      ) : (
                        <div className="space-y-2">
                          <Upload className="mx-auto h-12 w-12 text-gray-400" />
                          <p className="text-sm font-medium">
                            Click to upload or drag and drop
                          </p>
                          <p className="text-xs text-gray-500">
                            JPG, PNG, or GIF (max. 5MB)
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                
                <Button 
                  type="submit" 
                  className="w-full" 
                  disabled={!selectedFile || matchMutation.isPending}
                >
                  {matchMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Finding Matches...
                    </>
                  ) : (
                    'Find Matches'
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Results Section */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Matching Results</CardTitle>
                <CardDescription>
                  {matchMutation.isPending 
                    ? 'Analyzing pet images with AI...'
                    : matchMutation.isSuccess
                      ? matchMutation.data.message
                      : 'Upload a photo to see potential matches'
                  }
                </CardDescription>
              </CardHeader>
              <CardContent>
                {matchMutation.isPending && (
                  <div className="flex flex-col items-center justify-center py-10 space-y-4">
                    <Loader2 className="h-10 w-10 animate-spin text-primary" />
                    <p>Our AI is comparing your pet's photo with others in the database...</p>
                  </div>
                )}

                {matchMutation.isSuccess && matchMutation.data.matches?.length > 0 && (
                  <div className="space-y-6">
                    {matchMutation.data.matches.map((match: any, index: number) => (
                      <Card key={index} className="overflow-hidden">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="p-4">
                            <img 
                              src={match.pet.imageUrl} 
                              alt={match.pet.name || 'Pet'} 
                              className="w-full h-48 object-cover rounded-md"
                            />
                            <div className="mt-2">
                              <h3 className="font-semibold text-lg">{match.pet.name || 'Unknown name'}</h3>
                              <p className="text-sm text-gray-500 mt-1">
                                {match.pet.breed || 'Unknown breed'} • {match.pet.petType}
                              </p>
                              <p className="text-xs mt-1">
                                Last seen: {match.pet.lastSeenLocation || 'Unknown location'}
                              </p>
                            </div>
                          </div>
                          <div className="p-4 bg-gray-50">
                            <div className="flex items-center justify-between mb-2">
                              <h4 className="font-medium">Match Score:</h4>
                              <Badge className={getConfidenceBadgeColor(match.confidence)}>
                                {match.confidence.charAt(0).toUpperCase() + match.confidence.slice(1)} Confidence
                              </Badge>
                            </div>
                            <Progress 
                              value={match.score * 100} 
                              className={`h-2 ${getScoreColor(match.score)}`}
                            />
                            <p className="text-right text-xs mt-1">
                              {Math.round(match.score * 100)}% match
                            </p>
                            
                            <div className="mt-4">
                              <h4 className="font-medium mb-1">Why this might be a match:</h4>
                              <p className="text-sm text-gray-600">{match.reasoning}</p>
                            </div>
                            
                            <div className="mt-4">
                              <Button size="sm" className="w-full">
                                Contact Owner
                              </Button>
                            </div>
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>
                )}

                {matchMutation.isSuccess && (!matchMutation.data.matches || matchMutation.data.matches.length === 0) && (
                  <div className="py-8 text-center">
                    <p className="text-lg font-medium">No matches found</p>
                    <p className="text-sm text-gray-500 mt-2">
                      We couldn't find any potential matches for your pet in our database.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            {matchMutation.isSuccess && (
              <div className="text-center">
                <h3 className="text-lg font-medium mb-2">Don't see your pet?</h3>
                <p className="text-sm text-gray-600 mb-4">
                  Register your {status === PetStatus.LOST ? 'lost' : 'found'} pet so others can find it.
                </p>
                <Button variant="outline" asChild>
                  <a href={status === PetStatus.LOST ? '/lost-pet' : '/found-pet'}>
                    Register {status === PetStatus.LOST ? 'Lost' : 'Found'} Pet
                  </a>
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}