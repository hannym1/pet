import React from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useParams, useLocation } from 'wouter';
import { Helmet } from 'react-helmet';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Pet, PetStatus } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';
import { format } from 'date-fns';
import PetMatches from '@/components/pets/PetMatches';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
  CardFooter,
} from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  MapPin,
  Calendar,
  Mail,
  User,
  Tag,
  MessageSquare,
  Heart,
  ChevronLeft,
  AlertCircle,
  CheckCircle2,
} from 'lucide-react';

const PetDetails: React.FC = () => {
  const { id } = useParams();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const petId = parseInt(id);
  
  // Get pet details
  const { data: pet, isLoading, error } = useQuery({
    queryKey: [`/api/pets/${petId}`],
    enabled: !isNaN(petId),
  });
  
  // Mark as reunited mutation
  const reuniteWithPet = useMutation({
    mutationFn: async (matchedPetId: number) => {
      const response = await apiRequest('POST', `/api/pets/${petId}/reunite`, { matchedPetId });
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/pets/${petId}`] });
      toast({
        title: "Pet marked as reunited!",
        description: "Congratulations on finding your pet!",
        variant: "default",
      });
    },
    onError: (error) => {
      toast({
        title: "Error marking pet as reunited",
        description: (error as Error).message || "Please try again later",
        variant: "destructive",
      });
    },
  });
  
  const handleReunite = (matchedPetId: number) => {
    reuniteWithPet.mutate(matchedPetId);
  };
  
  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="animate-pulse">
            <div className="h-8 bg-neutral-200 w-2/3 mb-4 rounded"></div>
            <div className="h-4 bg-neutral-200 w-full mb-8 rounded"></div>
            
            <div className="flex flex-col md:flex-row gap-6">
              <div className="md:w-1/2">
                <div className="bg-neutral-200 h-80 w-full rounded-lg mb-4"></div>
                <div className="h-6 bg-neutral-200 w-full rounded mb-2"></div>
                <div className="h-6 bg-neutral-200 w-3/4 rounded"></div>
              </div>
              
              <div className="md:w-1/2">
                <div className="bg-neutral-200 h-12 w-full rounded mb-6"></div>
                <div className="space-y-4">
                  {Array(5).fill(0).map((_, i) => (
                    <div key={i} className="h-6 bg-neutral-200 w-full rounded"></div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  if (error || !pet) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-md mx-auto bg-red-50 p-6 rounded-lg text-center">
          <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-red-800 mb-2">Error Loading Pet Details</h2>
          <p className="text-red-700 mb-6">
            {(error as Error)?.message || "The pet you're looking for couldn't be found or has been removed."}
          </p>
          <Button onClick={() => navigate('/search')}>
            <ChevronLeft className="mr-2 h-4 w-4" />
            Back to Search
          </Button>
        </div>
      </div>
    );
  }
  
  const formattedDate = pet.lastSeenDate 
    ? format(new Date(pet.lastSeenDate), 'MMMM d, yyyy')
    : '';
  
  // Determine if it's a lost or found pet
  const isLost = pet.status === PetStatus.LOST;
  const isReunited = pet.status === PetStatus.REUNITED;
  
  return (
    <>
      <Helmet>
        <title>{`${pet.name} - ${pet.status.charAt(0).toUpperCase() + pet.status.slice(1)} ${pet.petType.charAt(0).toUpperCase() + pet.petType.slice(1)} | PetReunite`}</title>
        <meta 
          name="description" 
          content={`Help reunite ${pet.name}, a ${pet.status} ${pet.breed || pet.petType} ${isLost ? 'with their owner' : 'with their family'}. Last seen at ${pet.lastSeenLocation}.`}
        />
      </Helmet>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <Button
            variant="ghost"
            className="mb-4"
            onClick={() => navigate(-1)}
          >
            <ChevronLeft className="mr-2 h-4 w-4" />
            Back
          </Button>
          
          {isReunited && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6 flex items-center">
              <CheckCircle2 className="h-6 w-6 text-green-500 mr-3 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-green-800">This pet has been reunited!</h3>
                <p className="text-green-700 text-sm">
                  {pet.name} has been successfully reunited with {isLost ? 'their owner' : 'their family'}.
                </p>
              </div>
            </div>
          )}
          
          <div className="flex flex-col md:flex-row gap-6">
            {/* Left Column - Image and Status */}
            <div className="md:w-1/2">
              <div className="relative rounded-lg overflow-hidden mb-4">
                <img 
                  src={pet.imageUrl || `https://placehold.co/800x600/e2e8f0/64748b?text=${pet.name.charAt(0)}`} 
                  alt={`${pet.status} ${pet.petType} - ${pet.name}`}
                  className="w-full aspect-video object-cover"
                />
                <span 
                  className={`absolute top-4 left-4 text-white text-sm font-semibold px-3 py-1 rounded-full ${
                    isLost ? 'bg-accent' : isReunited ? 'bg-primary' : 'bg-secondary'
                  }`}
                >
                  {pet.status.charAt(0).toUpperCase() + pet.status.slice(1)}
                </span>
              </div>
              
              <h1 className="font-display font-bold text-2xl md:text-3xl text-neutral-800 mb-2">
                {pet.name}
              </h1>
              <p className="text-neutral-600 mb-4">
                {pet.breed 
                  ? `${pet.breed}, ${pet.gender || ''}`
                  : `${pet.petType.charAt(0).toUpperCase() + pet.petType.slice(1)}, ${pet.gender || ''}`}
              </p>
              
              {!isReunited && (
                <div className="space-y-3 mb-6">
                  {isLost ? (
                    <Button 
                      className="w-full bg-primary hover:bg-blue-600"
                      size="lg"
                      onClick={() => navigate(`/search?status=found&petType=${pet.petType}`)}
                    >
                      <Search className="mr-2 h-5 w-5" />
                      Browse Found Pets
                    </Button>
                  ) : (
                    <Button 
                      className="w-full bg-primary hover:bg-blue-600" 
                      size="lg"
                      onClick={() => navigate(`/search?status=lost&petType=${pet.petType}`)}
                    >
                      <Search className="mr-2 h-5 w-5" />
                      Browse Lost Pets
                    </Button>
                  )}

                  {isLost ? (
                    <Button 
                      variant="outline" 
                      className="w-full"
                      onClick={() => navigate('/found-pet')}
                    >
                      <Heart className="mr-2 h-5 w-5 text-secondary" />
                      I Found This Pet
                    </Button>
                  ) : (
                    <Button 
                      variant="outline" 
                      className="w-full"
                      onClick={() => navigate('/lost-pet')}
                    >
                      <Heart className="mr-2 h-5 w-5 text-accent" />
                      This Is My Pet
                    </Button>
                  )}
                </div>
              )}
            </div>
            
            {/* Right Column - Details */}
            <div className="md:w-1/2">
              <Card>
                <CardHeader>
                  <CardTitle>Pet Details</CardTitle>
                  <CardDescription>
                    {isLost 
                      ? "Information about this lost pet to help with identification"
                      : "Information about this found pet to help find its owner"}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {pet.lastSeenLocation && (
                    <div className="flex items-start gap-3">
                      <MapPin className="h-5 w-5 text-accent mt-0.5" />
                      <div>
                        <p className="font-medium">
                          {isLost ? "Last Seen Location" : "Found Location"}
                        </p>
                        <p className="text-neutral-600">{pet.lastSeenLocation}</p>
                      </div>
                    </div>
                  )}
                  
                  {formattedDate && (
                    <div className="flex items-start gap-3">
                      <Calendar className="h-5 w-5 text-primary mt-0.5" />
                      <div>
                        <p className="font-medium">
                          {isLost ? "Date Lost" : "Date Found"}
                        </p>
                        <p className="text-neutral-600">{formattedDate}</p>
                      </div>
                    </div>
                  )}
                  
                  {pet.description && (
                    <div className="flex items-start gap-3">
                      <MessageSquare className="h-5 w-5 text-neutral-500 mt-0.5" />
                      <div>
                        <p className="font-medium">Description</p>
                        <p className="text-neutral-600">{pet.description}</p>
                      </div>
                    </div>
                  )}
                  
                  {(pet.isChipped || pet.hasCollar) && (
                    <div className="flex items-start gap-3">
                      <Tag className="h-5 w-5 text-neutral-500 mt-0.5" />
                      <div>
                        <p className="font-medium">Identification</p>
                        <ul className="text-neutral-600 list-disc list-inside">
                          {pet.isChipped && (
                            <li>
                              Microchipped
                              {pet.chipId && ` (ID: ${pet.chipId})`}
                            </li>
                          )}
                          {pet.hasCollar && (
                            <li>
                              Wearing a collar
                              {pet.collarDescription && ` (${pet.collarDescription})`}
                            </li>
                          )}
                        </ul>
                      </div>
                    </div>
                  )}
                  
                  {pet.contactName && (
                    <div className="flex items-start gap-3">
                      <User className="h-5 w-5 text-neutral-500 mt-0.5" />
                      <div>
                        <p className="font-medium">Contact Person</p>
                        <p className="text-neutral-600">{pet.contactName}</p>
                      </div>
                    </div>
                  )}
                  
                  {pet.contactInfo && !isReunited && (
                    <div className="flex items-start gap-3">
                      <Mail className="h-5 w-5 text-neutral-500 mt-0.5" />
                      <div>
                        <p className="font-medium">Contact Information</p>
                        <p className="text-neutral-600">{pet.contactInfo}</p>
                      </div>
                    </div>
                  )}
                </CardContent>
                {!isReunited && pet.status === 'found' && pet.isTemporarilyCaredFor && (
                  <CardFooter className="bg-blue-50 px-6 py-3 text-sm text-blue-700">
                    <div className="flex items-center gap-2">
                      <Heart className="h-4 w-4 text-blue-600" />
                      <span>This pet is being temporarily cared for</span>
                    </div>
                  </CardFooter>
                )}
              </Card>
            </div>
          </div>
          
          {/* Tabs for Matches and Social Media */}
          {!isReunited && (
            <Tabs defaultValue="matches" className="mt-10">
              <TabsList className="mb-6">
                <TabsTrigger value="matches">Potential Matches</TabsTrigger>
                <TabsTrigger value="social">Social Media</TabsTrigger>
              </TabsList>
              
              <TabsContent value="matches">
                <div className="mb-6">
                  <h2 className="text-2xl font-display font-semibold mb-2">Potential Matches</h2>
                  <p className="text-neutral-600">
                    These pets have similar characteristics and were {isLost ? 'found' : 'lost'} in your area.
                    If you recognize a match, you can contact the {isLost ? 'finder' : 'owner'} directly.
                  </p>
                </div>
                
                <PetMatches petId={pet.id} petType={pet.petType} />
                
                {pet.matchedPetId && (
                  <div className="mt-6 bg-green-50 border border-green-100 rounded-lg p-4">
                    <h3 className="font-semibold text-green-800 mb-2">
                      <CheckCircle2 className="inline-block mr-2 h-5 w-5" />
                      Match Found!
                    </h3>
                    <p className="text-green-700">
                      This pet has been matched with another report. Please contact the {isLost ? 'finder' : 'owner'} to verify if this is the right pet.
                    </p>
                  </div>
                )}
                
                {!pet.matchedPetId && !isReunited && (
                  <div className="mt-6 flex justify-center">
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="outline" className="bg-green-50 text-green-700 hover:bg-green-100">
                          <CheckCircle2 className="mr-2 h-5 w-5" />
                          Mark as Reunited
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Mark as reunited?</AlertDialogTitle>
                          <AlertDialogDescription>
                            Has {pet.name} been reunited with {isLost ? 'you' : 'their owner'}? This will mark the pet as reunited and help others know this pet is no longer {pet.status}.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction 
                            className="bg-green-600 hover:bg-green-700"
                            onClick={() => handleReunite(pet.matchedPetId || 0)}
                          >
                            Yes, {pet.name} is Home!
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="social">
                <div className="mb-6">
                  <h2 className="text-2xl font-display font-semibold mb-2">Social Media Analysis</h2>
                  <p className="text-neutral-600">
                    Our AI is scanning social media platforms for posts about {isLost ? 'found pets' : 'lost pets'} that might match {pet.name}.
                  </p>
                </div>
                
                <div className="bg-neutral-50 p-8 rounded-xl text-center">
                  <SearchIcon className="h-12 w-12 text-neutral-400 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold mb-2">Scanning Social Media</h3>
                  <p className="text-neutral-600 max-w-md mx-auto mb-4">
                    We're actively monitoring Nextdoor, Facebook, and other platforms for potential matches.
                  </p>
                  <Button variant="outline">
                    Check Again
                  </Button>
                </div>
              </TabsContent>
            </Tabs>
          )}
        </div>
      </div>
    </>
  );
};

// Icons
const Search = (props: React.SVGProps<SVGSVGElement>) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    {...props}
  >
    <circle cx="11" cy="11" r="8" />
    <path d="m21 21-4.3-4.3" />
  </svg>
);

const SearchIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    {...props}
  >
    <circle cx="11" cy="11" r="8" />
    <path d="m21 21-4.3-4.3" />
  </svg>
);

export default PetDetails;
