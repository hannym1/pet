import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { Helmet } from 'react-helmet';
import { Pet, PetStatus, PetType } from '@shared/schema';
import PetCard from '@/components/pets/PetCard';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from '@/components/ui/skeleton';
import { Search as SearchIcon, Filter, MapPin } from 'lucide-react';

const Search: React.FC = () => {
  const [location, setLocation] = useLocation();
  
  // Parse URL params for initial filter values
  const params = new URLSearchParams(location.split('?')[1]);
  
  // State for filters
  const [filters, setFilters] = useState({
    status: params.get('status') || '',
    petType: params.get('petType') || '',
    location: params.get('location') || '',
    searchTerm: '',
  });
  
  // Query pets with filters
  const { data: pets, isLoading, error } = useQuery({
    queryKey: ['/api/pets', filters],
    staleTime: 1000 * 60 * 5, // 5 minutes
  });
  
  // Update URL with filters
  const updateUrlWithFilters = () => {
    const searchParams = new URLSearchParams();
    if (filters.status) searchParams.set('status', filters.status);
    if (filters.petType) searchParams.set('petType', filters.petType);
    if (filters.location) searchParams.set('location', filters.location);
    
    const newLocation = searchParams.toString() 
      ? `/search?${searchParams.toString()}` 
      : '/search';
    
    setLocation(newLocation, { replace: true });
  };
  
  // Handle filter changes
  const handleFilterChange = (key: string, value: string) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };
  
  // Apply filters
  const applyFilters = () => {
    updateUrlWithFilters();
  };
  
  // Clear filters
  const clearFilters = () => {
    setFilters({
      status: '',
      petType: '',
      location: '',
      searchTerm: '',
    });
    setLocation('/search', { replace: true });
  };
  
  // Filter the pets client-side if there's a search term
  const filteredPets = React.useMemo(() => {
    if (!pets) return [];
    
    if (!filters.searchTerm) return pets;
    
    const searchLower = filters.searchTerm.toLowerCase();
    return pets.filter((pet: Pet) => {
      const nameMatch = pet.name && pet.name.toLowerCase().includes(searchLower);
      const breedMatch = pet.breed && pet.breed.toLowerCase().includes(searchLower);
      const descMatch = pet.description && pet.description.toLowerCase().includes(searchLower);
      const locationMatch = pet.lastSeenLocation && pet.lastSeenLocation.toLowerCase().includes(searchLower);
      
      return nameMatch || breedMatch || descMatch || locationMatch;
    });
  }, [pets, filters.searchTerm]);

  return (
    <>
      <Helmet>
        <title>Search Pets - PetReunite</title>
        <meta 
          name="description" 
          content="Search for lost and found pets in your area. Filter by pet type, status, and location to find a match." 
        />
      </Helmet>

      <div className="bg-gradient-to-r from-primary/5 to-secondary/5 py-8">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h1 className="font-display font-bold text-3xl md:text-4xl text-neutral-800 mb-3 text-center">
              Search Pets
            </h1>
            <p className="text-neutral-600 text-lg text-center mb-8">
              Find lost and found pets in your area. Use the filters to narrow your search.
            </p>
            
            <div className="bg-white p-5 rounded-xl shadow-sm mb-8">
              <div className="flex flex-col md:flex-row gap-4 mb-4">
                <div className="relative flex-grow">
                  <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-neutral-400" />
                  <Input
                    type="text"
                    placeholder="Search by name, breed, or description..."
                    className="pl-10"
                    value={filters.searchTerm}
                    onChange={(e) => handleFilterChange('searchTerm', e.target.value)}
                  />
                </div>
                
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button 
                    variant="outline" 
                    className="flex items-center"
                    onClick={clearFilters}
                  >
                    Clear
                  </Button>
                </div>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-neutral-700 mb-1">Pet Status</label>
                  <Select 
                    value={filters.status} 
                    onValueChange={(value) => handleFilterChange('status', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="All statuses" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">All statuses</SelectItem>
                      <SelectItem value={PetStatus.LOST}>Lost</SelectItem>
                      <SelectItem value={PetStatus.FOUND}>Found</SelectItem>
                      <SelectItem value={PetStatus.REUNITED}>Reunited</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-neutral-700 mb-1">Pet Type</label>
                  <Select 
                    value={filters.petType} 
                    onValueChange={(value) => handleFilterChange('petType', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="All pet types" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">All pet types</SelectItem>
                      <SelectItem value={PetType.DOG}>Dog</SelectItem>
                      <SelectItem value={PetType.CAT}>Cat</SelectItem>
                      <SelectItem value={PetType.BIRD}>Bird</SelectItem>
                      <SelectItem value={PetType.OTHER}>Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-neutral-700 mb-1">Location</label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-neutral-400" />
                    <Input
                      type="text"
                      placeholder="City, neighborhood..."
                      className="pl-10"
                      value={filters.location}
                      onChange={(e) => handleFilterChange('location', e.target.value)}
                    />
                  </div>
                </div>
              </div>
              
              <div className="mt-4 flex justify-end">
                <Button 
                  onClick={applyFilters}
                  className="bg-primary hover:bg-blue-600"
                >
                  <Filter className="mr-2 h-4 w-4" />
                  Apply Filters
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          {isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {Array(6).fill(0).map((_, i) => (
                <div key={i} className="bg-white border border-neutral-200 rounded-xl overflow-hidden shadow-sm">
                  <Skeleton className="w-full h-64" />
                  <div className="p-5">
                    <div className="flex justify-between items-start mb-3">
                      <Skeleton className="h-6 w-32" />
                      <Skeleton className="h-4 w-16" />
                    </div>
                    <div className="mb-3">
                      <Skeleton className="h-4 w-full mb-1" />
                      <Skeleton className="h-4 w-3/4" />
                    </div>
                    <Skeleton className="h-20 w-full mb-4" />
                    <Skeleton className="h-10 w-full rounded-lg" />
                  </div>
                </div>
              ))}
            </div>
          ) : error ? (
            <div className="text-center py-10">
              <p className="text-red-500 mb-4">Error loading pets: {(error as Error).message}</p>
              <Button variant="outline" onClick={() => window.location.reload()}>
                Try Again
              </Button>
            </div>
          ) : filteredPets.length > 0 ? (
            <>
              <p className="text-neutral-600 mb-6">
                Showing {filteredPets.length} {filteredPets.length === 1 ? 'pet' : 'pets'}
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredPets.map((pet: Pet) => (
                  <PetCard key={pet.id} pet={pet} />
                ))}
              </div>
            </>
          ) : (
            <div className="text-center py-16">
              <SearchIcon className="h-12 w-12 text-neutral-300 mx-auto mb-4" />
              <h2 className="text-xl font-display font-semibold mb-2">No Pets Found</h2>
              <p className="text-neutral-600 max-w-md mx-auto mb-6">
                We couldn't find any pets matching your search criteria. Try adjusting your filters or search terms.
              </p>
              <Button variant="outline" onClick={clearFilters}>
                Clear Filters
              </Button>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default Search;
