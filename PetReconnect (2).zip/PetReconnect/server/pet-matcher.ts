import { Pet } from "@shared/schema";

// Interface for image comparison results
interface ImageComparisonResult {
  score: number;
  confidence: string;
}

/**
 * A utility class for comparing pet images and finding potential matches
 * This is a simplified version for the MVP
 */
export class PetMatcher {
  /**
   * Compare two pet images and return a similarity score
   * @param sourceImageUrl - URL of the source pet image
   * @param targetImageUrl - URL of the target pet image
   * @returns Promise<ImageComparisonResult> - The comparison results with score and confidence level
   */
  static async compareImages(
    sourceImageUrl: string,
    targetImageUrl: string
  ): Promise<ImageComparisonResult> {
    // This is a mock implementation for the MVP
    // In a real implementation, we would use TensorFlow.js or a similar library
    // to perform image comparison
    
    // For the MVP, we'll return a random score between 0.5 and 0.95
    const score = 0.5 + Math.random() * 0.45;
    
    // Determine confidence level based on score
    let confidence: string;
    if (score >= 0.85) {
      confidence = "high";
    } else if (score >= 0.7) {
      confidence = "medium";
    } else {
      confidence = "low";
    }
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));
    
    return { score, confidence };
  }
  
  /**
   * Find potential matches for a pet based on various criteria
   * @param sourcePet - The pet to find matches for
   * @param candidatePets - Array of pets to compare against
   * @returns Promise<Pet[]> - Array of potential matches sorted by relevance
   */
  static async findMatches(
    sourcePet: Pet,
    candidatePets: Pet[]
  ): Promise<Pet[]> {
    // Filter candidates by type and opposite status
    const oppositeStatus = sourcePet.status === "lost" ? "found" : "lost";
    const filteredCandidates = candidatePets.filter(pet => 
      pet.petType === sourcePet.petType && 
      pet.status === oppositeStatus &&
      pet.id !== sourcePet.id &&
      !pet.matchedPetId
    );
    
    // If no candidates match the basic criteria, return empty array
    if (filteredCandidates.length === 0) {
      return [];
    }
    
    // Score matches based on various factors
    const scoredMatches = await Promise.all(
      filteredCandidates.map(async (candidate) => {
        // Start with a base score
        let score = 0.5;
        
        // Add points for matching breed
        if (candidate.breed && sourcePet.breed && 
            candidate.breed.toLowerCase() === sourcePet.breed.toLowerCase()) {
          score += 0.15;
        }
        
        // Add points for matching gender
        if (candidate.gender && sourcePet.gender && 
            candidate.gender.toLowerCase() === sourcePet.gender.toLowerCase()) {
          score += 0.1;
        }
        
        // Add points for matching color
        if (candidate.color && sourcePet.color) {
          // Check if any color terms match
          const sourceColors = sourcePet.color.toLowerCase().split(/\s+and\s+|\s*,\s*|\s+/);
          const targetColors = candidate.color.toLowerCase().split(/\s+and\s+|\s*,\s*|\s+/);
          
          // Check for overlap in color terms
          const matchingColors = sourceColors.filter(color => 
            targetColors.some(targetColor => targetColor.includes(color) || color.includes(targetColor))
          );
          
          if (matchingColors.length > 0) {
            score += 0.1 * Math.min(matchingColors.length / sourceColors.length, 1);
          }
        }
        
        // Add points for having a collar (if specified in both)
        if (sourcePet.hasCollar === true && candidate.hasCollar === true) {
          score += 0.05;
          
          // Additional points for matching collar description
          if (sourcePet.collarDescription && candidate.collarDescription) {
            const sourceDesc = sourcePet.collarDescription.toLowerCase();
            const targetDesc = candidate.collarDescription.toLowerCase();
            
            if (sourceDesc.includes(targetDesc) || targetDesc.includes(sourceDesc)) {
              score += 0.05;
            }
          }
        }
        
        // Add points for chip match
        if (sourcePet.isChipped && candidate.isChipped && 
            sourcePet.chipId && candidate.chipId && 
            sourcePet.chipId === candidate.chipId) {
          score += 0.3; // Big boost for chip match
        }
        
        // Add points for geographic proximity (if we had geocoding)
        // For MVP, we'll just check if the location strings have any overlap
        if (sourcePet.lastSeenLocation && candidate.lastSeenLocation) {
          const sourceLoc = sourcePet.lastSeenLocation.toLowerCase();
          const targetLoc = candidate.lastSeenLocation.toLowerCase();
          
          // Check if locations share any words (like city or neighborhood names)
          const sourceWords = sourceLoc.split(/\s*,\s*|\s+/);
          const targetWords = targetLoc.split(/\s*,\s*|\s+/);
          
          const matchingLocWords = sourceWords.filter(word => 
            targetWords.includes(word) && word.length > 2 // Ignore short words like "in", "at", etc.
          );
          
          if (matchingLocWords.length > 0) {
            score += 0.1;
          }
        }
        
        // Add points for image similarity if both have images
        if (sourcePet.imageUrl && candidate.imageUrl) {
          try {
            const imageComparison = await PetMatcher.compareImages(
              sourcePet.imageUrl, 
              candidate.imageUrl
            );
            score += imageComparison.score * 0.3; // Image similarity is heavily weighted
          } catch (error) {
            console.error("Image comparison failed:", error);
            // Continue without image comparison
          }
        }
        
        // Calculate temporal proximity (days between sightings)
        if (sourcePet.lastSeenDate && candidate.lastSeenDate) {
          const sourceDate = new Date(sourcePet.lastSeenDate);
          const targetDate = new Date(candidate.lastSeenDate);
          const daysDiff = Math.abs(
            (sourceDate.getTime() - targetDate.getTime()) / (1000 * 60 * 60 * 24)
          );
          
          // Closer dates get higher scores (max 0.15 for same day, decreasing over 14 days)
          if (daysDiff <= 14) {
            score += 0.15 * (1 - daysDiff / 14);
          }
        }
        
        return {
          pet: candidate,
          score: Math.min(score, 1.0) // Cap at 1.0
        };
      })
    );
    
    // Sort by score (descending) and return only the pets
    return scoredMatches
      .sort((a, b) => b.score - a.score)
      .map(match => match.pet);
  }
}
