import express, { type Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { insertPetSchema, PetStatus, PetType } from "@shared/schema";
import { TextAnalyzer } from "./text-analyzer";
import { PetMatcher } from "./pet-matcher";
import * as tf from '@tensorflow/tfjs-node';
import path from 'path';
import { upload, getFullImageUrl } from './services/image-upload';
import { OpenAIService } from './services/openai-service';
import fs from 'fs';

// Initialize TensorFlow.js (placeholder for real implementation)
async function initializeTensorflow() {
  // This would load any pre-trained models in a real implementation
  console.log("TensorFlow.js initialized");
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // Initialize services
  await initializeTensorflow();
  
  // Serve uploaded files statically
  app.use('/uploads', express.static(path.join(process.cwd(), 'uploads')));
  
  // API Routes
  // Get all pets with optional filtering
  app.get("/api/pets", async (req: Request, res: Response) => {
    try {
      const filters = {
        status: req.query.status as string | undefined,
        petType: req.query.petType as string | undefined,
        location: req.query.location as string | undefined,
      };
      
      const pets = await storage.listPets(filters);
      res.json(pets);
    } catch (error) {
      console.error("Error fetching pets:", error);
      res.status(500).json({ message: "Failed to fetch pets" });
    }
  });
  
  // Get a single pet by ID
  app.get("/api/pets/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid pet ID" });
      }
      
      const pet = await storage.getPet(id);
      if (!pet) {
        return res.status(404).json({ message: "Pet not found" });
      }
      
      res.json(pet);
    } catch (error) {
      console.error("Error fetching pet:", error);
      res.status(500).json({ message: "Failed to fetch pet" });
    }
  });
  
  // Create a new pet report
  app.post("/api/pets", async (req: Request, res: Response) => {
    try {
      // Validate input
      const validatedData = insertPetSchema.parse(req.body);
      
      // Create the pet in storage
      const pet = await storage.createPet(validatedData);
      res.status(201).json(pet);
    } catch (error) {
      console.error("Error creating pet:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid pet data", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to create pet" });
    }
  });
  
  // Update a pet
  app.patch("/api/pets/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid pet ID" });
      }
      
      const pet = await storage.getPet(id);
      if (!pet) {
        return res.status(404).json({ message: "Pet not found" });
      }
      
      // Allow partial updates
      const updatedPet = await storage.updatePet(id, req.body);
      res.json(updatedPet);
    } catch (error) {
      console.error("Error updating pet:", error);
      res.status(500).json({ message: "Failed to update pet" });
    }
  });
  
  // Mark pets as reunited
  app.post("/api/pets/:id/reunite", async (req: Request, res: Response) => {
    try {
      const petId = parseInt(req.params.id);
      const { matchedPetId } = req.body;
      
      if (isNaN(petId) || isNaN(matchedPetId)) {
        return res.status(400).json({ message: "Invalid pet IDs" });
      }
      
      const success = await storage.markPetAsReunited(petId, matchedPetId);
      if (!success) {
        return res.status(404).json({ message: "One or both pets not found" });
      }
      
      res.json({ message: "Pets marked as reunited!" });
    } catch (error) {
      console.error("Error reuniting pets:", error);
      res.status(500).json({ message: "Failed to reunite pets" });
    }
  });
  
  // Get potential matches for a pet
  app.get("/api/pets/:id/matches", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid pet ID" });
      }
      
      const pet = await storage.getPet(id);
      if (!pet) {
        return res.status(404).json({ message: "Pet not found" });
      }
      
      // First get all potential matches based on type and status
      const candidatePets = await storage.listPets();
      
      // Then use PetMatcher to find and rank the most likely matches
      const matches = await PetMatcher.findMatches(pet, candidatePets);
      
      res.json(matches);
    } catch (error) {
      console.error("Error finding matches:", error);
      res.status(500).json({ message: "Failed to find matches" });
    }
  });
  
  // Mock endpoint for analyzing social media posts
  app.post("/api/analyze-post", async (req: Request, res: Response) => {
    try {
      const { content, platform, imageUrls } = req.body;
      
      if (!content) {
        return res.status(400).json({ message: "Post content is required" });
      }
      
      // Use TextAnalyzer to extract information from the post
      const analysis = TextAnalyzer.processPost(content);
      
      res.json({
        analysis,
        confidence: 0.85, // Mock confidence score
        imageAnalysis: imageUrls && imageUrls.length > 0 ? {
          detectedPet: true,
          petType: analysis.petType || "unknown",
          confidence: 0.78
        } : null
      });
    } catch (error) {
      console.error("Error analyzing post:", error);
      res.status(500).json({ message: "Failed to analyze post" });
    }
  });
  
  // Get success stories (reunited pets)
  app.get("/api/success-stories", async (req: Request, res: Response) => {
    try {
      const reunitedPets = await storage.listPets({ status: PetStatus.REUNITED });
      
      // Group reunited pets by match ID to get pairs
      const successStories = [];
      const processedIds = new Set();
      
      for (const pet of reunitedPets) {
        if (processedIds.has(pet.id)) continue;
        
        if (pet.matchedPetId && !processedIds.has(pet.matchedPetId)) {
          const matchedPet = reunitedPets.find(p => p.id === pet.matchedPetId);
          
          if (matchedPet) {
            successStories.push({
              lostPet: pet.status === 'lost' ? pet : matchedPet,
              foundPet: pet.status === 'found' ? pet : matchedPet,
              reuniteDate: pet.createdAt
            });
            
            processedIds.add(pet.id);
            processedIds.add(pet.matchedPetId);
          }
        }
      }
      
      res.json(successStories);
    } catch (error) {
      console.error("Error fetching success stories:", error);
      res.status(500).json({ message: "Failed to fetch success stories" });
    }
  });
  
  // Get statistics
  app.get("/api/stats", async (req: Request, res: Response) => {
    try {
      const allPets = await storage.listPets();
      
      const stats = {
        totalPets: allPets.length,
        lostPets: allPets.filter(pet => pet.status === PetStatus.LOST).length,
        foundPets: allPets.filter(pet => pet.status === PetStatus.FOUND).length,
        reunitedPets: allPets.filter(pet => pet.status === PetStatus.REUNITED).length,
        byType: {
          [PetType.DOG]: allPets.filter(pet => pet.petType === PetType.DOG).length,
          [PetType.CAT]: allPets.filter(pet => pet.petType === PetType.CAT).length,
          [PetType.BIRD]: allPets.filter(pet => pet.petType === PetType.BIRD).length,
          [PetType.OTHER]: allPets.filter(pet => pet.petType === PetType.OTHER).length,
        }
      };
      
      res.json(stats);
    } catch (error) {
      console.error("Error fetching stats:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  // Image upload and matching endpoints
  
  // Upload an image and find matches
  app.post("/api/image-match", upload.single('petImage'), async (req: Request, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No image uploaded" });
      }

      // Get the uploaded file info
      const uploadedFile = req.file;
      const fileUrl = getFullImageUrl(req, uploadedFile.filename);
      
      // Optional filters based on uploaded image
      const requestData = req.body;
      const petType = requestData.petType || undefined;
      const status = requestData.status || undefined; // If looking for a lost/found pet
      
      // Get the status opposite to what we're searching for (e.g., if lost, find "found" pets)
      const searchStatus = status === PetStatus.LOST ? PetStatus.FOUND : PetStatus.LOST;
      
      // Get potential candidates from database
      const candidates = await storage.listPets({ 
        status: searchStatus, 
        petType: petType 
      });
      
      if (candidates.length === 0) {
        return res.json({
          uploadedImageUrl: fileUrl,
          message: "No potential matches found in the database",
          matches: []
        });
      }

      // Only compare with pets that have images
      const candidatesWithImages = candidates.filter(pet => pet.imageUrl);
      
      if (candidatesWithImages.length === 0) {
        return res.json({
          uploadedImageUrl: fileUrl,
          message: "No potential matches with images found",
          matches: []
        });
      }

      // Prepare candidate images for comparison
      const imageUrls = candidatesWithImages.map(pet => ({
        id: pet.id,
        imageUrl: pet.imageUrl
      }));

      // Use OpenAI to find potential matches
      const matches = await OpenAIService.findPotentialMatches(fileUrl, imageUrls);
      
      // Add pet details to matches
      const matchesWithPetInfo = matches.map(match => {
        const pet = candidatesWithImages.find(p => p.id === match.petId);
        return {
          ...match,
          pet
        };
      });

      // Only return high confidence matches or top 3
      const highConfidenceMatches = matchesWithPetInfo.filter(m => m.score > 0.7);
      const topMatches = highConfidenceMatches.length > 0 
        ? highConfidenceMatches 
        : matchesWithPetInfo.slice(0, 3);

      return res.json({
        uploadedImageUrl: fileUrl,
        message: topMatches.length > 0 
          ? "Potential matches found" 
          : "No strong matches found, but here are some possibilities",
        matches: topMatches
      });
    } catch (error) {
      console.error("Error matching image:", error);
      res.status(500).json({ message: "Failed to process image matching" });
    }
  });
  
  // Analyze a single pet image
  app.post("/api/analyze-pet-image", upload.single('petImage'), async (req: Request, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No image uploaded" });
      }

      // Get the uploaded file info
      const uploadedFile = req.file;
      const fileUrl = getFullImageUrl(req, uploadedFile.filename);
      
      // Analyze the image using OpenAI
      const analysis = await OpenAIService.analyzePetImage(fileUrl);
      
      return res.json({
        uploadedImageUrl: fileUrl,
        analysis
      });
    } catch (error) {
      console.error("Error analyzing pet image:", error);
      res.status(500).json({ message: "Failed to analyze pet image" });
    }
  });

  return httpServer;
}
