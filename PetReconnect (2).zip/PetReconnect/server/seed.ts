import { db } from "./db";
import { pets, socialMediaPosts, users } from "@shared/schema";
import { log } from "./vite";
import { eq, and, like, ilike } from "drizzle-orm";

// Mock data for seeding the database
async function seed() {
  log("Starting database seeding...", "seed");

  try {
    // Check if we have any existing data
    const existingPets = await db.select().from(pets).limit(1);
    if (existingPets.length > 0) {
      log("Database already seeded, skipping...", "seed");
      return;
    }

    log("Seeding database with initial data...", "seed");

    // Create a test user
    const [testUser] = await db.insert(users).values([
      { username: "testuser", password: "password123" }
    ]).returning();
    
    log(`Created test user: ${testUser.username}`, "seed");

    // Create lost pets
    const lostPets = [
      {
        name: "Charlie",
        status: "lost",
        petType: "dog",
        breed: "Cocker Spaniel",
        gender: "Male",
        color: "Brown and white",
        description: "Brown and white spaniel, wearing a blue collar with a bone-shaped tag. Very friendly, responds to 'Charlie'.",
        lastSeenDate: new Date("2023-11-01"),
        lastSeenLocation: "Highland Park, Austin",
        contactName: "Sarah Williams",
        contactInfo: "sarah.w@example.com",
        imageUrl: "https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        isChipped: true,
        chipId: "123456789",
        hasCollar: true,
        collarDescription: "Blue collar with bone-shaped tag",
        additionalInfo: "He's very friendly and loves treats",
        isTemporarilyCaredFor: false
      },
      {
        name: "Max",
        status: "lost",
        petType: "dog",
        breed: "Border Collie",
        gender: "Male",
        color: "Black and white",
        description: "Black and white border collie with a red collar and ID tag. Microchipped. Very energetic and might be scared.",
        lastSeenDate: new Date("2023-11-02"),
        lastSeenLocation: "Lakeway, Austin",
        contactName: "John Doe",
        contactInfo: "john.doe@example.com",
        imageUrl: "https://images.unsplash.com/photo-1589652717521-10c0d092dea9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        isChipped: true,
        chipId: "987654321",
        hasCollar: true,
        collarDescription: "Red collar with ID tag",
        additionalInfo: "He's very energetic and might be scared",
        isTemporarilyCaredFor: false
      },
      {
        name: "Bella",
        status: "lost",
        petType: "dog",
        breed: "Golden Retriever",
        gender: "Female",
        color: "Golden",
        description: "Golden retriever with a pink collar. Very friendly and loves people. Responds to 'Bella'.",
        lastSeenDate: new Date("2023-11-03"),
        lastSeenLocation: "Downtown Austin",
        contactName: "Emily Johnson",
        contactInfo: "emily.j@example.com",
        imageUrl: "https://images.unsplash.com/photo-1537151608828-ea2b11777ee8?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        isChipped: false,
        chipId: null,
        hasCollar: true,
        collarDescription: "Pink collar with heart-shaped tag",
        additionalInfo: "She's very friendly and loves people",
        isTemporarilyCaredFor: false
      },
      {
        name: "Milo",
        status: "lost",
        petType: "cat",
        breed: "Siamese",
        gender: "Male",
        color: "Cream with brown points",
        description: "Siamese cat with blue eyes and a blue collar. Very vocal and shy with strangers.",
        lastSeenDate: new Date("2023-11-04"),
        lastSeenLocation: "Round Rock, Austin Metropolitan Area",
        contactName: "Michael Brown",
        contactInfo: "michael.b@example.com",
        imageUrl: "https://images.unsplash.com/photo-1529778873920-4da4926a72c2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        isChipped: true,
        chipId: "567891234",
        hasCollar: true,
        collarDescription: "Blue collar with bell",
        additionalInfo: "He's very vocal and shy with strangers",
        isTemporarilyCaredFor: false
      },
      {
        name: "Luna",
        status: "lost",
        petType: "cat",
        breed: "Maine Coon",
        gender: "Female",
        color: "Tabby with white chest",
        description: "Large Maine Coon cat with a fluffy tail and green eyes. Very friendly and may approach people.",
        lastSeenDate: new Date("2023-11-05"),
        lastSeenLocation: "Barton Creek, Austin",
        contactName: "Jessica Smith",
        contactInfo: "jessica.s@example.com",
        imageUrl: "https://images.unsplash.com/photo-1533738363-b7f9aef128ce?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        isChipped: false,
        chipId: null,
        hasCollar: false,
        collarDescription: null,
        additionalInfo: "She's very friendly and may approach people",
        isTemporarilyCaredFor: false
      },
      {
        name: "Polly",
        status: "lost",
        petType: "bird",
        breed: "African Grey Parrot",
        gender: "Female",
        color: "Grey with red tail",
        description: "Grey parrot with red tail feathers. Can say 'Hello' and 'Polly wants a cracker'. May be scared of people.",
        lastSeenDate: new Date("2023-11-06"),
        lastSeenLocation: "South Lamar, Austin",
        contactName: "Robert Wilson",
        contactInfo: "robert.w@example.com",
        imageUrl: "https://images.unsplash.com/photo-1612024782955-49fae79e42bb?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        isChipped: false,
        chipId: null,
        hasCollar: false,
        collarDescription: null,
        additionalInfo: "She can say 'Hello' and 'Polly wants a cracker'",
        isTemporarilyCaredFor: false
      }
    ];
    
    // Create found pets
    const foundPets = [
      {
        name: "Unknown Cat",
        status: "found",
        petType: "cat",
        breed: "Orange Tabby",
        gender: "Female",
        color: "Orange",
        description: "Friendly orange tabby cat, no collar, appears well-fed and groomed. Very affectionate and likely someone's pet.",
        lastSeenDate: new Date("2023-11-07"),
        lastSeenLocation: "Westlake, Austin",
        contactName: "David Lee",
        contactInfo: "david.l@example.com",
        imageUrl: "https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        isChipped: false,
        chipId: null,
        hasCollar: false,
        collarDescription: null,
        additionalInfo: "Very affectionate and likely someone's pet",
        isTemporarilyCaredFor: true
      },
      {
        name: "Unknown Dog",
        status: "found",
        petType: "dog",
        breed: "Labrador Retriever",
        gender: "Male",
        color: "Yellow",
        description: "Yellow lab, no collar but appears well-cared for. Very friendly and responds to basic commands like sit and stay.",
        lastSeenDate: new Date("2023-11-08"),
        lastSeenLocation: "Mueller, Austin",
        contactName: "Amanda Taylor",
        contactInfo: "amanda.t@example.com",
        imageUrl: "https://images.unsplash.com/photo-1543466835-00a7907e9de1?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        isChipped: true,
        chipId: "Will check at vet",
        hasCollar: false,
        collarDescription: null,
        additionalInfo: "Very friendly and responds to basic commands",
        isTemporarilyCaredFor: true
      },
      {
        name: "Unknown Cat",
        status: "found",
        petType: "cat",
        breed: "Calico",
        gender: "Female",
        color: "Calico (white, orange, black)",
        description: "Small calico cat found hiding under a porch. Appears to be young, possibly 1-2 years old. Friendly but scared.",
        lastSeenDate: new Date("2023-11-09"),
        lastSeenLocation: "East Austin",
        contactName: "Daniel White",
        contactInfo: "daniel.w@example.com",
        imageUrl: "https://images.unsplash.com/photo-1506891536236-3e07892564b7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        isChipped: false,
        chipId: null,
        hasCollar: false,
        collarDescription: null,
        additionalInfo: "Found hiding under a porch, appears young",
        isTemporarilyCaredFor: true
      },
      {
        name: "Unknown Dog",
        status: "found",
        petType: "dog",
        breed: "Pug",
        gender: "Male",
        color: "Fawn",
        description: "Older pug with grey muzzle, wearing a worn leather collar with no tags. Very friendly and well-behaved.",
        lastSeenDate: new Date("2023-11-10"),
        lastSeenLocation: "North Austin",
        contactName: "Jennifer Garcia",
        contactInfo: "jennifer.g@example.com",
        imageUrl: "https://images.unsplash.com/photo-1553698217-934b000f1f00?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        isChipped: false,
        chipId: null,
        hasCollar: true,
        collarDescription: "Worn leather collar with no tags",
        additionalInfo: "Older dog with grey muzzle, very friendly",
        isTemporarilyCaredFor: true
      },
      {
        name: "Unknown Bird",
        status: "found",
        petType: "bird",
        breed: "Cockatiel",
        gender: "Unknown",
        color: "Grey and yellow",
        description: "Grey cockatiel with yellow face markings. Very tame and comfortable with people. Found flying near a park.",
        lastSeenDate: new Date("2023-11-11"),
        lastSeenLocation: "Zilker Park, Austin",
        contactName: "Michelle Rodriguez",
        contactInfo: "michelle.r@example.com",
        imageUrl: "https://images.unsplash.com/photo-1552728089-57bdde30beb3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        isChipped: false,
        chipId: null,
        hasCollar: false,
        collarDescription: null,
        additionalInfo: "Very tame and comfortable with people",
        isTemporarilyCaredFor: true
      }
    ];

    // Insert pets
    await db.insert(pets).values([...lostPets, ...foundPets]);
    log(`Added ${lostPets.length} lost pets and ${foundPets.length} found pets`, "seed");

    // Create a successful reunion case - Max (dog) is reunited
    const maxPet = await db.select().from(pets).where(ilike(pets.name, 'Max')).limit(1);
    const foundDog = await db.select().from(pets).where(
      and(
        eq(pets.status, 'found'),
        eq(pets.petType, 'dog'),
        like(pets.breed, '%Labrador%')
      )
    ).limit(1);

    if (maxPet.length > 0 && foundDog.length > 0) {
      // Mark both pets as reunited
      await db.update(pets)
        .set({ 
          status: 'reunited',
          matchedPetId: foundDog[0].id
        })
        .where(eq(pets.id, maxPet[0].id));
      
      await db.update(pets)
        .set({ 
          status: 'reunited',
          matchedPetId: maxPet[0].id
        })
        .where(eq(pets.id, foundDog[0].id));
      
      log(`Created a reunion story between ${maxPet[0].name} and a found ${foundDog[0].breed}`, "seed");
    }

    // Create social media posts
    const socialPosts = [
      {
        platform: "Nextdoor",
        postId: "nd-123456",
        postUrl: "https://nextdoor.com/post/123456",
        content: "LOST DOG: My golden retriever Sunny went missing from the Barton Creek area yesterday afternoon. She's very friendly, has a red collar with tags. Please call or text me if you see her: 512-555-0123. She needs her medication!",
        imageUrls: ["https://images.unsplash.com/photo-1564501049412-61c2a3083791?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"],
        postedAt: new Date("2023-11-15"),
        location: "Barton Creek, Austin"
      },
      {
        platform: "Facebook",
        postId: "fb-789012",
        postUrl: "https://facebook.com/groups/austinpets/posts/789012",
        content: "FOUND CAT in North Austin near Burnet Rd. Grey tabby, very affectionate, no collar but well-groomed. Appears to be an indoor cat. I've taken him to the vet, no microchip. Please share to help find the owner! Contact me at austin.pet.lover@email.com",
        imageUrls: ["https://images.unsplash.com/photo-1596854407944-bf87f6fdd49e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"],
        postedAt: new Date("2023-11-16"),
        location: "North Austin"
      }
    ];

    await db.insert(socialMediaPosts).values(socialPosts);
    log(`Added ${socialPosts.length} social media posts`, "seed");

    log("Database seeding completed successfully!", "seed");
  } catch (error) {
    log(`Error seeding database: ${error}`, "seed");
    console.error(error);
  }
}

export default seed;