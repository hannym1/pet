import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { nanoid } from 'nanoid';
import { log } from '../vite';

// Create uploads directory if it doesn't exist
const uploadsDir = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
  log(`Created uploads directory at ${uploadsDir}`, 'upload');
}

// Configure storage settings
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadsDir);
  },
  filename: function (req, file, cb) {
    // Generate unique filename with original extension
    const fileExt = path.extname(file.originalname);
    const uniqueId = nanoid(10);
    const uniqueName = `pet_${Date.now()}_${uniqueId}${fileExt}`;
    cb(null, uniqueName);
  }
});

// Configure upload restrictions
const fileFilter = (req: Express.Request, file: Express.Multer.File, cb: multer.FileFilterCallback) => {
  // Only allow image files
  if (file.mimetype.startsWith('image/')) {
    cb(null, true);
  } else {
    cb(new Error('Only image files are allowed'));
  }
};

// Create multer instance with configured settings
export const upload = multer({
  storage: storage,
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB max file size
  },
  fileFilter: fileFilter
});

/**
 * Gets the public URL for an uploaded file
 * @param fileName - The name of the file
 * @returns The public URL that can be used to access the file
 */
export function getPublicFileUrl(fileName: string): string {
  // In a production environment, this would point to a CDN or properly configured URL
  // For this demo, we'll use a local path
  return `${process.env.PUBLIC_URL || ''}/uploads/${fileName}`;
}

/**
 * Utility function to generate a full URL for an image
 * @param req - Express request object
 * @param fileName - Name of the uploaded file
 * @returns Full URL to access the image
 */
export function getFullImageUrl(req: any, fileName: string): string {
  const protocol = req.headers['x-forwarded-proto'] || req.protocol;
  const host = req.headers.host;
  return `${protocol}://${host}/uploads/${fileName}`;
}