import OpenAI from "openai";
import { log } from "../vite";

// Initialize OpenAI with API key
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// The newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user

/**
 * Service for image analysis and comparison using OpenAI
 */
export class OpenAIService {
  /**
   * Compare two pet images and determine if they might be the same pet
   * @param sourceImageUrl - URL of the source pet image
   * @param targetImageUrl - URL of the target pet image
   * @returns Promise with comparison results including confidence score and match likelihood
   */
  static async compareImages(sourceImageUrl: string, targetImageUrl: string): Promise<{
    score: number;
    confidence: string;
    reasoning: string;
    isSamePet: boolean;
  }> {
    try {
      log(`Comparing images: ${sourceImageUrl} with ${targetImageUrl}`, 'openai');
      
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are an expert in pet identification. Your task is to analyze two pet images and determine if they show the same animal. Consider breed characteristics, fur patterns, distinct markings, face shape, and other identifiable features."
          },
          {
            role: "user",
            content: [
              {
                type: "text", 
                text: "Compare these two pet images and tell me if they show the same animal. Respond with a JSON object that includes: 'score' (a number from 0 to 1 where 1 is certainty they're the same pet), 'confidence' (a string: 'low', 'medium', or 'high'), 'reasoning' (your detailed explanation), and 'isSamePet' (a boolean true/false)."
              },
              {
                type: "image_url",
                image_url: { url: sourceImageUrl }
              },
              {
                type: "image_url",
                image_url: { url: targetImageUrl }
              }
            ]
          }
        ],
        response_format: { type: "json_object" },
        max_tokens: 1000
      });

      const result = JSON.parse(response.choices[0].message.content);
      
      // Ensure we have all required properties
      return {
        score: typeof result.score === 'number' ? result.score : 0,
        confidence: result.confidence || 'low',
        reasoning: result.reasoning || 'Unable to provide reasoning',
        isSamePet: !!result.isSamePet
      };
    } catch (error) {
      log(`Error comparing images: ${error}`, 'openai');
      console.error('OpenAI image comparison error:', error);
      
      // Return a default response in case of error
      return {
        score: 0,
        confidence: 'low',
        reasoning: `Error analyzing images: ${error.message || 'Unknown error'}`,
        isSamePet: false
      };
    }
  }

  /**
   * Analyze a single pet image to extract features
   * @param imageUrl - URL of the pet image to analyze
   * @returns Promise with analysis results
   */
  static async analyzePetImage(imageUrl: string): Promise<{
    petType: string;
    breed: string;
    color: string;
    distinguishingFeatures: string[];
    confidence: number;
  }> {
    try {
      log(`Analyzing pet image: ${imageUrl}`, 'openai');
      
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are an expert in animal identification. Your task is to analyze pet images and identify key characteristics."
          },
          {
            role: "user",
            content: [
              {
                type: "text", 
                text: "Analyze this pet image and provide the following information in JSON format: 'petType' (dog, cat, bird, etc.), 'breed' (be specific if possible, or 'mixed/unknown'), 'color', 'distinguishingFeatures' (array of notable markings or characteristics), and 'confidence' (number from 0-1 indicating your confidence in the analysis)."
              },
              {
                type: "image_url",
                image_url: { url: imageUrl }
              }
            ]
          }
        ],
        response_format: { type: "json_object" },
        max_tokens: 500
      });

      const result = JSON.parse(response.choices[0].message.content);
      
      // Ensure we have all required properties
      return {
        petType: result.petType || 'unknown',
        breed: result.breed || 'unknown',
        color: result.color || '',
        distinguishingFeatures: Array.isArray(result.distinguishingFeatures) ? result.distinguishingFeatures : [],
        confidence: typeof result.confidence === 'number' ? result.confidence : 0.5
      };
    } catch (error) {
      log(`Error analyzing pet image: ${error}`, 'openai');
      console.error('OpenAI pet analysis error:', error);
      
      // Return a default response in case of error
      return {
        petType: 'unknown',
        breed: 'unknown',
        color: '',
        distinguishingFeatures: [],
        confidence: 0
      };
    }
  }

  /**
   * Find potential matches for a pet image against a collection of other pet images
   * @param sourceImageUrl - URL of the source pet image
   * @param candidateImageUrls - Array of URLs for candidate pet images to compare against
   * @returns Promise with an array of match results, sorted by match score (highest first)
   */
  static async findPotentialMatches(
    sourceImageUrl: string,
    candidateImageUrls: {id: number, imageUrl: string}[]
  ): Promise<{
    petId: number,
    score: number,
    confidence: string,
    reasoning: string,
    isSamePet: boolean
  }[]> {
    const results = [];
    
    // First, analyze the source image to determine pet type
    const sourceAnalysis = await this.analyzePetImage(sourceImageUrl);
    log(`Source image analysis: ${JSON.stringify(sourceAnalysis)}`, 'openai');
    
    // Process candidates in batches to avoid rate limiting
    const batchSize = 3;
    for (let i = 0; i < candidateImageUrls.length; i += batchSize) {
      const batch = candidateImageUrls.slice(i, i + batchSize);
      
      // Process batch in parallel
      const batchPromises = batch.map(async (candidate) => {
        const comparison = await this.compareImages(sourceImageUrl, candidate.imageUrl);
        return {
          petId: candidate.id,
          ...comparison
        };
      });
      
      const batchResults = await Promise.all(batchPromises);
      results.push(...batchResults);
      
      // Add a small delay between batches to avoid rate limiting
      if (i + batchSize < candidateImageUrls.length) {
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    }
    
    // Sort results by score (highest first)
    return results.sort((a, b) => b.score - a.score);
  }
}