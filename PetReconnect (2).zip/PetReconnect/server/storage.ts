import { 
  users, type User, type InsertUser,
  pets, type Pet, type InsertPet,
  socialMediaPosts, type SocialMediaPost, type InsertSocialMediaPost
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, asc, or, like, isNull, not } from "drizzle-orm";

// Extend the interface with the necessary CRUD methods
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Pet methods
  createPet(pet: InsertPet): Promise<Pet>;
  getPet(id: number): Promise<Pet | undefined>;
  updatePet(id: number, pet: Partial<Pet>): Promise<Pet | undefined>;
  deletePet(id: number): Promise<boolean>;
  listPets(filters?: {
    status?: string;
    petType?: string;
    location?: string;
  }): Promise<Pet[]>;
  findPotentialMatches(petId: number): Promise<Pet[]>;
  markPetAsReunited(petId: number, matchedPetId: number): Promise<boolean>;
  
  // Social media posts methods
  createSocialMediaPost(post: InsertSocialMediaPost): Promise<SocialMediaPost>;
  getSocialMediaPost(id: number): Promise<SocialMediaPost | undefined>;
  listUnprocessedSocialMediaPosts(): Promise<SocialMediaPost[]>;
  markSocialMediaPostAsProcessed(id: number, extractedData: {
    petType?: string;
    status?: string;
    contactInfo?: string;
  }): Promise<SocialMediaPost | undefined>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async createPet(pet: InsertPet): Promise<Pet> {
    const [newPet] = await db
      .insert(pets)
      .values({
        ...pet,
        matchedPetId: null,
        extractedContact: null,
        sourcePost: null
      })
      .returning();
    return newPet;
  }

  async getPet(id: number): Promise<Pet | undefined> {
    const [pet] = await db.select().from(pets).where(eq(pets.id, id));
    return pet || undefined;
  }

  async updatePet(id: number, updatedFields: Partial<Pet>): Promise<Pet | undefined> {
    const [updatedPet] = await db
      .update(pets)
      .set(updatedFields)
      .where(eq(pets.id, id))
      .returning();
    return updatedPet || undefined;
  }

  async deletePet(id: number): Promise<boolean> {
    const result = await db
      .delete(pets)
      .where(eq(pets.id, id))
      .returning({ id: pets.id });
    return result.length > 0;
  }

  async listPets(filters?: {
    status?: string;
    petType?: string;
    location?: string;
  }): Promise<Pet[]> {
    let query = db.select().from(pets);
    
    if (filters) {
      const conditions = [];
      
      if (filters.status) {
        conditions.push(eq(pets.status, filters.status));
      }
      
      if (filters.petType) {
        conditions.push(eq(pets.petType, filters.petType));
      }
      
      if (filters.location && filters.location.trim() !== '') {
        conditions.push(like(pets.lastSeenLocation, `%${filters.location.trim()}%`));
      }
      
      if (conditions.length > 0) {
        query = query.where(and(...conditions));
      }
    }
    
    // Sort by most recent first
    return await query.orderBy(desc(pets.createdAt));
  }

  async findPotentialMatches(petId: number): Promise<Pet[]> {
    const [pet] = await db.select().from(pets).where(eq(pets.id, petId));
    
    if (!pet) return [];
    
    // If the pet is lost, find found pets that match
    // If the pet is found, find lost pets that match
    const oppositeStatus = pet.status === 'lost' ? 'found' : 'lost';
    
    return await db
      .select()
      .from(pets)
      .where(
        and(
          eq(pets.status, oppositeStatus),
          eq(pets.petType, pet.petType),
          not(eq(pets.id, petId)),
          isNull(pets.matchedPetId)
        )
      )
      .orderBy(desc(pets.createdAt));
  }

  async markPetAsReunited(petId: number, matchedPetId: number): Promise<boolean> {
    // First, check if both pets exist
    const [pet] = await db.select().from(pets).where(eq(pets.id, petId));
    const [matchedPet] = await db.select().from(pets).where(eq(pets.id, matchedPetId));
    
    if (!pet || !matchedPet) return false;
    
    // Update first pet
    await db
      .update(pets)
      .set({
        status: 'reunited',
        matchedPetId: matchedPetId
      })
      .where(eq(pets.id, petId));
    
    // Update matched pet
    await db
      .update(pets)
      .set({
        status: 'reunited',
        matchedPetId: petId
      })
      .where(eq(pets.id, matchedPetId));
    
    return true;
  }

  async createSocialMediaPost(post: InsertSocialMediaPost): Promise<SocialMediaPost> {
    const [newPost] = await db
      .insert(socialMediaPosts)
      .values({
        ...post,
        isProcessed: false,
        extractedPetType: null,
        extractedStatus: null,
        extractedContactInfo: null
      })
      .returning();
    
    return newPost;
  }

  async getSocialMediaPost(id: number): Promise<SocialMediaPost | undefined> {
    const [post] = await db
      .select()
      .from(socialMediaPosts)
      .where(eq(socialMediaPosts.id, id));
    
    return post || undefined;
  }

  async listUnprocessedSocialMediaPosts(): Promise<SocialMediaPost[]> {
    return await db
      .select()
      .from(socialMediaPosts)
      .where(eq(socialMediaPosts.isProcessed, false))
      .orderBy(desc(socialMediaPosts.createdAt));
  }

  async markSocialMediaPostAsProcessed(
    id: number, 
    extractedData: {
      petType?: string;
      status?: string;
      contactInfo?: string;
    }
  ): Promise<SocialMediaPost | undefined> {
    const [updatedPost] = await db
      .update(socialMediaPosts)
      .set({
        isProcessed: true,
        extractedPetType: extractedData.petType || null,
        extractedStatus: extractedData.status || null,
        extractedContactInfo: extractedData.contactInfo || null
      })
      .where(eq(socialMediaPosts.id, id))
      .returning();
    
    return updatedPost || undefined;
  }
}

// Export the DatabaseStorage instance
export const storage = new DatabaseStorage();