/**
 * A utility class for analyzing text from social media posts to extract pet information
 * This is a simple implementation for the MVP
 */
export class TextAnalyzer {
  // Common keywords for lost pets
  private static lostKeywords = [
    "lost", "missing", "disappeared", "ran away", "escape", "stolen", "can't find"
  ];
  
  // Common keywords for found pets
  private static foundKeywords = [
    "found", "rescued", "picked up", "spotted", "stray", "wandering", "showed up"
  ];
  
  // Common pet types
  private static petTypeKeywords = {
    "dog": ["dog", "puppy", "canine", "pup", "pooch"],
    "cat": ["cat", "kitten", "feline", "kitty"],
    "bird": ["bird", "parrot", "parakeet", "cockatiel", "budgie", "macaw", "cockatoo", "canary", "finch"],
    "other": ["rabbit", "guinea pig", "hamster", "ferret", "reptile", "snake", "lizard", "turtle"]
  };
  
  /**
   * Determine if a post is about a lost pet
   * @param text - The post content to analyze
   * @returns boolean - True if the post is likely about a lost pet
   */
  static isLostPetPost(text: string): boolean {
    const lowerText = text.toLowerCase();
    return this.lostKeywords.some(keyword => lowerText.includes(keyword));
  }
  
  /**
   * Determine if a post is about a found pet
   * @param text - The post content to analyze
   * @returns boolean - True if the post is likely about a found pet
   */
  static isFoundPetPost(text: string): boolean {
    const lowerText = text.toLowerCase();
    return this.foundKeywords.some(keyword => lowerText.includes(keyword));
  }
  
  /**
   * Extract the pet type from the post
   * @param text - The post content to analyze
   * @returns string|null - The pet type or null if not detected
   */
  static extractPetType(text: string): string | null {
    const lowerText = text.toLowerCase();
    
    for (const [type, keywords] of Object.entries(this.petTypeKeywords)) {
      if (keywords.some(keyword => lowerText.includes(keyword))) {
        return type;
      }
    }
    
    return null;
  }
  
  /**
   * Extract contact information from the post
   * @param text - The post content to analyze
   * @returns object - Contact information found in the text
   */
  static extractContactInfo(text: string): {
    phone?: string,
    email?: string,
    username?: string
  } {
    const result: {
      phone?: string,
      email?: string,
      username?: string
    } = {};
    
    // Find phone numbers
    const phoneRegex = /(\+?1[-\s.]?)?(\(?\d{3}\)?[-\s.]?)?\d{3}[-\s.]\d{4}/g;
    const phoneMatches = text.match(phoneRegex);
    if (phoneMatches && phoneMatches.length > 0) {
      result.phone = phoneMatches[0].trim();
    }
    
    // Find emails
    const emailRegex = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g;
    const emailMatches = text.match(emailRegex);
    if (emailMatches && emailMatches.length > 0) {
      result.email = emailMatches[0].trim();
    }
    
    // Find usernames (@username)
    const usernameRegex = /@[a-zA-Z0-9._-]+/g;
    const usernameMatches = text.match(usernameRegex);
    if (usernameMatches && usernameMatches.length > 0) {
      result.username = usernameMatches[0].trim();
    }
    
    return result;
  }
  
  /**
   * Extract the location from the post
   * @param text - The post content to analyze
   * @returns string|null - The location or null if not detected
   */
  static extractLocation(text: string): string | null {
    // Common location indicators
    const locationPrefixes = [
      "in", "at", "near", "around", "by", "close to"
    ];
    
    // Try to find location using common patterns
    for (const prefix of locationPrefixes) {
      const pattern = new RegExp(`${prefix}\\s+([\\w\\s,]+?)(?:\\.|,|$|\\s+and\\s+)`, "i");
      const match = text.match(pattern);
      if (match && match[1]) {
        return match[1].trim();
      }
    }
    
    // Look for "last seen" pattern
    const lastSeenPattern = /last\s+seen\s+(?:in|at|near)?\s+([A-Za-z0-9\s,]+)(?:\.|,|$)/i;
    const lastSeenMatch = text.match(lastSeenPattern);
    if (lastSeenMatch && lastSeenMatch[1]) {
      return lastSeenMatch[1].trim();
    }
    
    return null;
  }
  
  /**
   * Extract a description of the pet from the text
   * @param text - The post content to analyze
   * @returns object - Description information found in the text
   */
  static extractPetDescription(text: string): {
    breed?: string,
    color?: string,
    gender?: string,
    name?: string,
    collarDescription?: string
  } {
    const result: {
      breed?: string,
      color?: string,
      gender?: string,
      name?: string,
      collarDescription?: string
    } = {};
    
    // Common breeds (simplified list)
    const dogBreeds = [
      "labrador", "retriever", "german shepherd", "golden retriever", "bulldog", "beagle",
      "poodle", "rottweiler", "yorkshire terrier", "boxer", "dachshund", "shih tzu"
    ];
    
    const catBreeds = [
      "siamese", "persian", "maine coon", "ragdoll", "bengal", "abyssinian",
      "birman", "oriental", "sphynx", "british shorthair", "scottish fold"
    ];
    
    // Find breed
    const lowerText = text.toLowerCase();
    
    // Check for dog breeds
    for (const breed of dogBreeds) {
      if (lowerText.includes(breed)) {
        result.breed = breed;
        break;
      }
    }
    
    // If no dog breed found, check for cat breeds
    if (!result.breed) {
      for (const breed of catBreeds) {
        if (lowerText.includes(breed)) {
          result.breed = breed;
          break;
        }
      }
    }
    
    // Find pet name
    const namePattern = /'([A-Za-z]+)'|"([A-Za-z]+)"|named\s+([A-Za-z]+)|name\s+is\s+([A-Za-z]+)/i;
    const nameMatch = text.match(namePattern);
    if (nameMatch) {
      // Find the first non-undefined capturing group
      for (let i = 1; i < nameMatch.length; i++) {
        if (nameMatch[i]) {
          result.name = nameMatch[i];
          break;
        }
      }
    }
    
    // Find gender
    if (lowerText.includes("male") || lowerText.includes("boy") || lowerText.includes("he")) {
      result.gender = "Male";
    } else if (lowerText.includes("female") || lowerText.includes("girl") || lowerText.includes("she")) {
      result.gender = "Female";
    }
    
    // Find color
    const colorPattern = /(?:is|coat|fur|color|colour)\s+(?:a\s+)?([a-zA-Z\s]+?(?:colored|coloured|brown|black|white|tan|golden|orange|grey|gray|yellow|cream|blue|red|tabby)[\w\s]*?)(?:\.|,|and)/i;
    const colorMatch = text.match(colorPattern);
    if (colorMatch && colorMatch[1]) {
      result.color = colorMatch[1].trim();
    }
    
    // Find collar description
    const collarPattern = /(?:wearing|has)\s+(?:a\s+)?([a-zA-Z\s]+?collar[\w\s]*?)(?:\.|,|and)/i;
    const collarMatch = text.match(collarPattern);
    if (collarMatch && collarMatch[1]) {
      result.collarDescription = collarMatch[1].trim() + " collar";
    }
    
    return result;
  }
  
  /**
   * Process a social media post to extract all relevant pet information
   * @param postContent - The content of the social media post
   * @returns object - All extracted information
   */
  static processPost(postContent: string): {
    status: string | null,
    petType: string | null,
    location: string | null,
    contactInfo: { phone?: string, email?: string, username?: string },
    description: {
      breed?: string,
      color?: string,
      gender?: string,
      name?: string,
      collarDescription?: string
    }
  } {
    // Determine post type (lost or found)
    let status = null;
    if (this.isLostPetPost(postContent)) {
      status = "lost";
    } else if (this.isFoundPetPost(postContent)) {
      status = "found";
    }
    
    return {
      status,
      petType: this.extractPetType(postContent),
      location: this.extractLocation(postContent),
      contactInfo: this.extractContactInfo(postContent),
      description: this.extractPetDescription(postContent)
    };
  }
}
