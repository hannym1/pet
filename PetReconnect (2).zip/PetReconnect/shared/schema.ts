import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Pet status enum
export const PetStatus = {
  LOST: "lost",
  FOUND: "found",
  REUNITED: "reunited",
} as const;

export type PetStatusType = typeof PetStatus[keyof typeof PetStatus];

// Pet type enum
export const PetType = {
  DOG: "dog",
  CAT: "cat",
  BIRD: "bird",
  OTHER: "other",
} as const;

export type PetTypeValue = typeof PetType[keyof typeof PetType];

// Pet schema
export const pets = pgTable("pets", {
  id: serial("id").primaryKey(),
  name: text("name"),
  status: text("status").notNull(),
  petType: text("pet_type").notNull(),
  breed: text("breed"),
  gender: text("gender"),
  color: text("color"),
  age: text("age"),
  description: text("description"),
  lastSeenDate: timestamp("last_seen_date"),
  lastSeenLocation: text("last_seen_location"),
  contactName: text("contact_name"),
  contactInfo: text("contact_info").notNull(),
  imageUrl: text("image_url"),
  isChipped: boolean("is_chipped"),
  chipId: text("chip_id"),
  hasCollar: boolean("has_collar"),
  collarDescription: text("collar_description"),
  additionalInfo: text("additional_info"),
  isTemporarilyCaredFor: boolean("is_temporarily_cared_for"),
  createdAt: timestamp("created_at").defaultNow(),
  sourcePost: text("source_post"),
  extractedContact: jsonb("extracted_contact"),
  // If the pet has been reunited, we'll store the matching pet ID
  matchedPetId: integer("matched_pet_id"),
});

export const insertPetSchema = createInsertSchema(pets).omit({
  id: true,
  createdAt: true,
  matchedPetId: true,
  extractedContact: true,
  sourcePost: true,
});

export type InsertPet = z.infer<typeof insertPetSchema>;
export type Pet = typeof pets.$inferSelect;

// Social media post schema (for mock scraping functionality)
export const socialMediaPosts = pgTable("social_media_posts", {
  id: serial("id").primaryKey(),
  platform: text("platform").notNull(),
  postId: text("post_id").notNull(),
  postUrl: text("post_url"),
  content: text("content").notNull(),
  imageUrls: text("image_urls").array(),
  postedAt: timestamp("posted_at"),
  location: text("location"),
  extractedPetType: text("extracted_pet_type"),
  extractedStatus: text("extracted_status"),
  extractedContactInfo: text("extracted_contact_info"),
  isProcessed: boolean("is_processed").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertSocialMediaPostSchema = createInsertSchema(socialMediaPosts).omit({
  id: true,
  createdAt: true,
  isProcessed: true,
  extractedPetType: true,
  extractedStatus: true,
  extractedContactInfo: true,
});

export type InsertSocialMediaPost = z.infer<typeof insertSocialMediaPostSchema>;
export type SocialMediaPost = typeof socialMediaPosts.$inferSelect;
